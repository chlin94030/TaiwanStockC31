import copy,gzip,json,sqlite3,time
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import pandas as pd
import pytest
from kosto.published import encode,decode,digest,MARKER,PublishedClient,GitHub
from kosto.promotion import advance,beats,control
from kosto.forward_book import record,mark
from kosto.panel import Panel,build_panel
from kosto.bundle import build_bundle
from kosto.store import Store
from kosto.sources.synthetic import write_demo
from kosto.config import load_config
from kosto.cloud_research import offset_bundle,recipes,evaluate
from kosto.publication_builder import build


def payload(day='2026-10-30',state='research'):
    return {'schema':1,'state':state,'research_date':day,'market_date':day,'published_at':day+'T22:00:00+08:00',
        'models':{h:{'id':h,'asof':day,'picks':[{'ticker':'2330','rank':1,'coverage':1.,'score':70.,'reasons':['測試']}],'certified':False,
            'label':'研究候選','weights':{},'metric':{},'curve':{},'recipe':{'model':{'k':5}}} for h in ('short','mid','long')},
        'stocks':{'2330':{'name':'台積電','board':'TWSE','group':'半導體','close':100,'asof':day,'plans':{},'ranks':{}}},'charts':{},'chart_shards':{},'synthetic':False}

def finish_thread(client):
    for _ in range(200):
        if not client.running:return
        time.sleep(.005)
    raise AssertionError('背景讀取未結束')

class FakeRemote:
    def __init__(self,p,bad=False):
        self.raw=encode(p);self.sha=digest(self.raw);self.bad=bad;self.downloads=0
    def release(self,tag):
        if tag=='alpharadar-status':return {'body':json.dumps({'stage':'published','research_date':'2026-10-30'})}
        return {'body':MARKER+json.dumps({'asset':'dashboard-'+self.sha+'.json.gz','sha256':self.sha,'research_date':'2026-10-30'}),
                'assets':[{'name':'dashboard-'+self.sha+'.json.gz'}]}
    def asset(self,a):self.downloads+=1;return self.raw+b'broken' if self.bad else self.raw
    def runs(self):return [{'status':'completed','conclusion':'success'}]

def test_publication_roundtrip_rejects_mixed_dates_and_synthetic_certification():
    p=payload();assert decode(encode(p))==p
    p['models']['mid']['asof']='2026-10-29'
    with pytest.raises(ValueError):encode(p)
    p=payload();p['synthetic']=True;p['models']['short']['certified']=True
    with pytest.raises(ValueError):encode(p)

def test_bounded_decompression(monkeypatch):
    import kosto.published as pub
    monkeypatch.setattr(pub,'MAX_JSON',100)
    with pytest.raises(ValueError):decode(gzip.compress(b' '*500))

def test_failed_or_incomplete_publish_preserves_last_good(tmp_path):
    old=payload('2026-10-29');cache=tmp_path/'artifacts/published_dashboard.json.gz';cache.parent.mkdir();cache.write_bytes(encode(old))
    remote=FakeRemote(payload(),True);c=PublishedClient(tmp_path,github=remote)
    c.refresh();finish_thread(c)
    assert c.payload==old and decode(cache.read_bytes())==old
    assert c.status['runs'][0]['conclusion']=='success'  # API job state does not replace validated data

def test_viewer_caches_unchanged_publication_and_never_builds_database(tmp_path,monkeypatch):
    import kosto.build
    monkeypatch.setattr(kosto.build.Builder,'run',lambda s:(_ for _ in ()).throw(AssertionError('viewer built database')))
    remote=FakeRemote(payload());c=PublishedClient(tmp_path,github=remote);c.refresh();finish_thread(c)
    assert c.payload['research_date']=='2026-10-30' and remote.downloads==1
    c.refresh(force=True);finish_thread(c);assert remote.downloads==1
    assert not (tmp_path/'data').exists()
    cold=PublishedClient(tmp_path,github=remote);assert cold.payload==c.payload

def test_snapshot_upload_precedes_single_pointer_switch(tmp_path):
    class Fake(GitHub):
        def __init__(self):self.calls=[]
        def upload(self,tag,path,replace=False):self.calls.append('asset');return {}
        def release(self,*a):return {'id':1,'assets':[],'body':''}
        def api(self,path,method='GET',**kw):self.calls.append(method);return {'updated_at':'2026-10-30T14:02:00Z'}
    g=Fake();p=tmp_path/'dashboard.json.gz';p.write_bytes(encode(payload()))
    m=g.publish(p,{});assert g.calls==['asset','PATCH'];assert m['sha256']==digest(p.read_bytes())
    assert m['announced_at'].endswith('Z')

def test_concurrent_first_release_creation_recovers_existing_release():
    import requests
    class Fake(GitHub):
        calls=0
        def __init__(self):pass
        def api(self,path,method='GET',**kw):
            self.calls+=1
            if method=='POST':
                response=requests.Response();response.status_code=422
                raise requests.HTTPError(response=response)
            return None if self.calls==1 else {'id':2,'assets':[]}
    assert Fake().release('alpharadar-data',True)['id']==2

def test_failed_checkpoint_upload_keeps_previous_database_and_ignores_unfinished_asset(tmp_path):
    import requests
    old={'id':1,'name':'data-price.tar.gz','state':'uploaded','updated_at':'2026-10-29'}
    pending={'id':3,'name':'data-price-'+'b'*64+'.tar.gz','state':'starter','updated_at':'2026-10-31'}
    complete={'id':2,'name':'data-price-'+'a'*64+'.tar.gz','state':'uploaded','updated_at':'2026-10-30'}
    rel={'id':1,'assets':[old,complete,pending],'upload_url':'https://uploads.github.com/test{?name}'}
    class Session:
        def post(self,*a,**kw):raise requests.ConnectionError('upload interrupted')
    class Fake(GitHub):
        def __init__(self):self.s=Session();self.headers={};self.writes=[]
        def release(self,*a):return rel
        def api(self,path,method='GET',**kw):self.writes.append(method)
    g=Fake();p=tmp_path/'data-price.tar.gz';p.write_bytes(b'new partial data')
    with pytest.raises(requests.ConnectionError):g.upload('alpharadar-data',p,replace=True)
    assert g.writes==[] and g.archive_asset(rel,p.name)==complete

def test_bad_checkpoint_checksum_does_not_replace_existing_local_file(tmp_path):
    class Response:
        def __enter__(self):return self
        def __exit__(self,*args):pass
        def raise_for_status(self):pass
        def iter_content(self,*args):yield b'corrupted download'
    class Session:
        def get(self,*args,**kw):return Response()
    class Fake(GitHub):
        def __init__(self):self.s=Session();self.headers={}
        def release(self,tag):return {'assets':[{'id':1,'name':'data-price-'+'a'*64+'.tar.gz','url':'https://api.github.com/asset'}]}
    dest=tmp_path/'data-price.tar.gz';dest.write_bytes(b'last good checkpoint')
    with pytest.raises(ValueError):Fake().download('alpharadar-data',dest.name,dest)
    assert dest.read_bytes()==b'last good checkpoint' and not dest.with_suffix('.download').exists()

def result(id='a',gain=.1):
    return {'id':id,'recipe':{'id':id},'eligible':True,'synthetic':False,'offset_count':5,'window':'same',
        'metric':{'cagr':gain+.2,'excess_cagr':gain,'info_ratio':1.2},'folds':{'1':gain,'2':gain,'3':gain}}

def test_switch_requires_distinct_consecutive_sessions_and_cooldown():
    cal=[str(x.date()) for x in pd.bdate_range('2026-01-01',periods=50)]
    s={'champions':{'mid':{'id':'a','recipe':{'id':'a'},'since':cal[0]}},'leaders':{},'history':[],'locks':{},'evaluated_date':cal[20]}
    for i in range(21,30):s=advance(s,cal[i],cal,{'mid':[result(),result('b',.13)]})
    assert s['champions']['mid']['id']=='a' and s['leaders']['mid']['streak']==9
    duplicate=advance(s,cal[29],cal,{'mid':[result(),result('b',.13)]});assert duplicate==s
    s=advance(s,cal[30],cal,{'mid':[result(),result('b',.13)]})
    assert s['champions']['mid']['id']=='b' and not s['champions']['mid']['certified']
    old=control(s,'mid','rollback',cal[31]);assert old['champions']['mid']['id']=='a' and old['locks']['mid']

def test_fold_regression_or_locked_model_blocks_promotion():
    a,b=result(),result('b',.2);b['folds']['1']=-.2;assert not beats(b,a)
    b=result('b',.2);b['window']='different';assert not beats(b,a)
    calendar=[str(x.date()) for x in pd.bdate_range('2026-01-01',periods=40)]
    s={'champions':{'mid':{'id':'a','since':calendar[0]}},'leaders':{},'history':[],'locks':{'mid':True}}
    for d in calendar[21:]:s=advance(s,d,calendar,{'mid':[a,result('b',.2)]})
    assert s['champions']['mid']['id']=='a'

def test_no_synthetic_production_champion():
    r=result();r['synthetic']=True
    assert not advance({},'2026-10-30',['2026-10-30'],{'mid':[r]}).get('champions')

def test_forward_publication_is_immutable_and_late_publish_does_not_fill_past_open():
    p=payload('2026-10-01');p['published_at']='2026-10-02T09:01:00+08:00'
    b=record({},p);p['models']['short']['picks']=[];assert record(b,p)==b
    days=pd.bdate_range('2026-10-01',periods=85);P=Panel(days,pd.Index(['2330']))
    for k,v in [('ret',.01),('oc',.005),('gap',.005),('tradable',True)]:P.m[k]=pd.DataFrame(v,index=days,columns=P.tickers)
    marked=mark(b,P);short=next(x for x in marked['publications'] if x['horizon']=='short')
    assert short['results'][0]['entry']=='2026-10-05' and short['status']=='matured'
    assert short['net_return']<(1.01**5-1)
    P.m['gap'].loc['2026-10-05']=.1
    missed=mark(b,P);assert next(x for x in missed['publications'] if x['horizon']=='short')['results'][0]['status']=='未成交'

def test_failed_state_restore_cannot_overwrite_cloud_state(tmp_path,monkeypatch):
    monkeypatch.chdir(tmp_path)
    from kosto.cloud_cli import save_state
    with pytest.raises(RuntimeError):save_state()

def test_checkpoint_rejects_symlink_and_path_traversal(tmp_path):
    import tarfile,io
    from kosto.remote import unpack
    p=tmp_path/'bad.tar.gz'
    with tarfile.open(p,'w:gz') as t:
        a=tarfile.TarInfo('../outside');a.size=1;t.addfile(a,io.BytesIO(b'x'))
    with pytest.raises(ValueError):unpack(tmp_path/'data',p)
    with tarfile.open(p,'w:gz') as t:
        a=tarfile.TarInfo('link');a.type=tarfile.SYMTYPE;a.linkname='/tmp';t.addfile(a)
    with pytest.raises(ValueError):unpack(tmp_path/'data',p)

@pytest.fixture(scope='module')
def daily_world(tmp_path_factory):
    root=tmp_path_factory.mktemp('cloud-daily');store=Store(root/'data');write_demo(store,70,seed=4,start='2017-01-02',end='2024-12-31')
    cfg=load_config(overrides={'research':{'signal_step':1,'start':'2018-01-01','holdout_months':12},'pools':{'sizes':[60,100]}})
    P=build_panel(store);B=build_bundle(P,cfg,log=lambda _:None);B.meta['data_identity']='synthetic-fixture'
    return SimpleNamespace(root=root,P=P,B=B,cfg=cfg)

def test_five_offsets_partition_daily_signals_without_rebuilding_factors(daily_world):
    B=daily_world.B;all_dates=[]
    for o in range(5):
        b=offset_bundle(B,o);all_dates+=b.meta['sig_dates'];assert np.all(b.sig_pos%5==o)
        assert b.a['R'] is B.a['R'];assert b.a['FWD'].shape[1]==len(b.sig_dates)
    assert sorted(all_dates)==B.meta['sig_dates']

def test_cloud_research_producer_and_schema_end_to_end(daily_world):
    w=daily_world;results={};state={'champions':{}}
    for h in ('short','mid','long'):
        recipe=recipes(w.cfg,h)[2];recipe['size']=60;recipe['rule']='ADV'
        r=evaluate(w.B,recipe);assert r['synthetic'] and r['offset_count']==5
        assert r['curve']['date'][-1]<str(w.B.sig_dates[-1].date())
        results[h]=[r];state['champions'][h]={'id':r['id']}
    p,shards=build(w.B,w.P,state,results,{'publications':[]},w.root)
    assert p['synthetic'] and not any(m['certified'] for m in p['models'].values())
    assert decode(encode(p))==p and len(shards)==10 and all(s.exists() for s in shards)
    atomic_path=w.root/'dashboard.json.gz';atomic_path.write_bytes(encode(p))
    assert atomic_path.stat().st_size<2_000_000

def test_workflow_writes_are_checkpointed_and_scheduled():
    import yaml
    root=Path(__file__).resolve().parents[1];raw=(root/'.github/workflows/pipeline.yml').read_text()
    cfg=yaml.load(raw,Loader=yaml.BaseLoader)
    assert cfg['on']['schedule'][0]['cron']=='10 15 * * 1-5'
    assert cfg['concurrency']['cancel-in-progress']=='false'
    assert 'cloud checkpoint' in raw and 'cloud save-state' in raw and "if: ${{ always() }}" in raw
    assert raw==(root/'pipeline_workflow_COPY.txt').read_text()
