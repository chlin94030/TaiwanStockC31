"""V30 regression tests. MemoryStore isolates scheduling from the Parquet engine."""
import copy,tempfile,threading,time,unittest
from pathlib import Path
from unittest.mock import patch
import numpy as np
import pandas as pd
from kosto import build as build_module
from kosto.build import Builder
from kosto.store import Store,KEYS
from kosto.config import load_config
from kosto.sources import official as O
from kosto.model_policy import regularize,LENSES
from kosto.research_pipeline import run_batch,recent_segment
from kosto.strategy_lab import Registry,Lab,candidate_set,evaluate,readiness,_setup
from kosto.sources.synthetic import generate
from kosto.panel import build_panel
from kosto.bundle import build_bundle


class MemoryStore(Store):
    """Actual JSON progress ledger; in-memory tables, NOT a Parquet validation."""
    tables={}
    def append(self,dataset,frame):
        if frame is None or frame.empty:return 0
        key=(str(self.root),dataset);old=self.tables.get(key,pd.DataFrame())
        result=pd.concat([old,frame],ignore_index=True).drop_duplicates(KEYS[dataset],keep='last')
        self.tables[key]=result.copy();return len(frame)
    def read(self,dataset,start=None,end=None,columns=None):
        f=self.tables.get((str(self.root),dataset),pd.DataFrame()).copy()
        if not f.empty and 'date' in f:
            if start is not None:f=f.loc[f.date>=pd.Timestamp(start)]
            if end is not None:f=f.loc[f.date<=pd.Timestamp(end)]
        return f[columns] if columns and not f.empty else f


class PipelineTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
        self.cfg=load_config(overrides={'data':{'dir':str(self.root),'start':'2024-06-03','end':'2024-06-07','pause_sec':0,'latest_first':True}})
    def tearDown(self):self.temp.cleanup()
    def price(self,d,board):
        return pd.DataFrame([{'date':d,'ticker':'2330' if board=='TWSE' else '5347','board':board,'close':100}])
    def test_round_robin_pause_saves_and_resume_skips(self):
        stop=threading.Event();calls=[];events=[]
        def fetch(_,d,board):
            calls.append((board,str(d.date())))
            if len(calls)==3:stop.set()
            return self.price(d,board)
        with patch.object(build_module,'Store',MemoryStore),patch.object(O.Official,'twse_price',lambda s,d:fetch(s,d,'TWSE')),patch.object(O.Official,'tpex_price',lambda s,d:fetch(s,d,'TPEX')):
            b=Builder(self.cfg,'price',stop_event=stop,event=lambda **e:events.append(e),log=lambda _:None);b.run()
            self.assertEqual([x[0] for x in calls],['TWSE','TPEX','TWSE'])
            self.assertEqual(calls[0][1],'2024-06-07');self.assertEqual(calls[2][1],'2024-06-06')
            self.assertIn('2024-06-06',MemoryStore(self.root,'price').done_set('price:TWSE'))
            stop.clear();before=list(calls);Builder(self.cfg,'price',log=lambda _:None).run()
            self.assertFalse(set(before)&set(calls[3:]));self.assertEqual(len(calls),10)
            self.assertGreater(events[0]['total'],0)
    def test_blocked_market_does_not_starve_other_market(self):
        def fail(*a):raise O.SourceError('維護')
        with patch.object(build_module,'Store',MemoryStore),patch.object(O.Official,'twse_price',fail),patch.object(O.Official,'tpex_price',lambda s,d:self.price(d,'TPEX')):
            b=Builder(self.cfg,'price',log=lambda _:None);r=b.run()['price']
            self.assertTrue(r['blocked']);self.assertEqual(r['failed'],3)
            self.assertEqual(len(b.store.done_set('price:TPEX')),5);self.assertFalse(b.store.done_set('price:TWSE'))
    def test_one_request_deadline_does_not_end_whole_batch(self):
        def fail(*a):raise O.FetchInterrupted('單一來源逾時')
        with patch.object(build_module,'Store',MemoryStore),patch.object(O.Official,'twse_price',fail),patch.object(O.Official,'tpex_price',lambda s,d:self.price(d,'TPEX')):
            b=Builder(self.cfg,'price',log=lambda _:None);r=b.run()['price']
            self.assertEqual(len(b.store.done_set('price:TPEX')),5);self.assertEqual(r['failed'],3)
    def test_unknown_status_is_not_holiday(self):
        for parser,payload in [(O.parse_twse_price,{'stat':'維護中'}),(O.parse_tpex_price,{'stat':'維護中'})]:
            with self.assertRaises(O.SourceError):parser(payload,'2024-06-03')
    def test_wrong_date_rejected_then_official_route_fallback(self):
        from tests.fixtures.official_samples import TWSE_MI_INDEX_20240613
        class Http:
            calls=0
            def get(self,*a):
                self.calls+=1;j=copy.deepcopy(TWSE_MI_INDEX_20240613);j['date']='20240612' if self.calls==1 else '20240613';return j
        http=Http();f=O.Official(http).twse_price('2024-06-13')
        self.assertEqual(http.calls,2);self.assertIn('2330',set(f.ticker))
    def test_timeout_before_request_and_pause(self):
        h=O.Http(pause=0,deadline=time.time()-1)
        with patch.object(h.s,'get') as get:
            with self.assertRaises(O.FetchInterrupted):h.get('https://example.test')
            get.assert_not_called()
        event=threading.Event();event.set();h=O.Http(stop_event=event)
        with self.assertRaises(O.FetchInterrupted):h.check()
    def test_no_backoff_after_last_retry(self):
        import requests
        h=O.Http(pause=0,retries=2,log=lambda _:None);waits=[]
        with patch.object(h.s,'get',side_effect=requests.ConnectionError('offline')),patch.object(h,'wait',side_effect=waits.append):
            with self.assertRaises(O.SourceError):h.get('https://example.test')
        self.assertEqual(len(waits),1)
    def test_sparse_old_new_data_is_not_long_history(self):
        f=pd.DataFrame({'date':pd.to_datetime(['2017-01-03','2017-01-04','2026-10-27','2026-10-28'])})
        self.assertEqual(len(recent_segment(f)),2)
    def test_pipeline_saves_inventory_when_one_group_fails(self):
        from kosto import research_pipeline as pipeline
        prices=pd.DataFrame([{'date':pd.Timestamp('2024-06-03'),'ticker':'2330','close':100}])
        MemoryStore(self.root/'data').append('price',prices)
        calls=[];events=[]
        class FakeBuilder:
            def __init__(self,cfg,group,**kw):self.group=group;calls.append((group,kw['budget_minutes']))
            def run(self):
                if self.group=='margin':raise O.SourceError('維護')
                return {'rows':1}
        with patch.object(pipeline,'Store',MemoryStore),patch.object(build_module,'Store',MemoryStore):
            result=run_batch(self.root,threading.Event(),lambda **kw:events.append(kw),budget_minutes=.1,builder_cls=FakeBuilder)
        self.assertIsNone(result);self.assertEqual(len(calls),5)
        self.assertTrue(any('inventory' in e for e in events));self.assertEqual(events[-1]['status'],'本批已保存，可繼續補齊')
    def test_pause_disables_automatic_restart(self):
        lab=Lab(self.root);self.assertTrue(lab.registry.get('continuous'));lab.pause()
        self.assertFalse(lab.registry.get('continuous'));self.assertTrue(lab.stop_event.is_set())
    def test_restart_does_not_keep_running_status(self):
        Registry(self.root).set('progress',{'status':'背景建置研究資料','done':99,'total':1000})
        self.assertIn('重啟',Lab(self.root).state['status'])
    def test_partial_raw_prices_feed_chart_cache_before_bundle(self):
        from kosto.auto_market import AutoMarket
        market=AutoMarket(self.root,online=False);folder=self.root/'data'/'raw'/'price';folder.mkdir(parents=True);(folder/'2024.parquet').touch()
        days=pd.bdate_range('2024-01-01',periods=70)
        frame=pd.DataFrame({'date':days,'ticker':'2330','open':100,'high':102,'low':99,'close':101,'volume':3000})
        market.picks=lambda h:pd.DataFrame({'ticker':['2330']})
        with patch.object(pd,'read_parquet',return_value=frame):
            market.sync_research_prices()
            for _ in range(100):
                if not market.raw_syncing:break
                time.sleep(.01)
        self.assertEqual(len(market.frames['2330']),70);self.assertEqual(market.frames['2330'].volume.iloc[-1],3)
        self.assertFalse((self.root/'artifacts'/'research_bundle.npz').exists())
    def test_zero_total_ui_never_prints_zero_over_zero(self):
        import sys,types,importlib
        fake=types.ModuleType('streamlit');records=[]
        fake.cache_resource=lambda **kw:lambda f:f
        fake.fragment=lambda **kw:lambda f:f
        fake.write=lambda x:records.append(str(x));fake.caption=lambda x:records.append(str(x))
        fake.progress=lambda *a,**kw:records.append(kw.get('text',''))
        class Box:
            def __enter__(self):return self
            def __exit__(self,*a):pass
        fake.expander=lambda *a,**kw:Box();fake.json=lambda *a:None
        previous=sys.modules.pop('kosto.lab_ui',None)
        try:
            with patch.dict(sys.modules,{'streamlit':fake}):
                ui=importlib.import_module('kosto.lab_ui')
                class LabState:
                    state={'status':'背景建置研究資料','done':0,'total':0}
                    def tick(self):pass
                ui._progress(LabState())
            self.assertFalse(any('0/0' in x for x in records));self.assertIn('背景建置研究資料',records)
        finally:
            sys.modules.pop('kosto.lab_ui',None)
            if previous:sys.modules['kosto.lab_ui']=previous
    def test_numeric_risk_is_not_overwritten_by_comment(self):
        from kosto.auto_market import screen,read_snapshot,SEED
        data=screen(read_snapshot(SEED),'long')
        self.assertIn('risk_observation',data)
        self.assertTrue(data.loc[data.history_days<16,'risk_observation'].isna().all())
        self.assertTrue(data['risk'].map(lambda x:isinstance(x,str)).all())
    def test_global_context_uses_previous_session_not_five_day_base(self):
        from kosto.global_markets import fetch_global
        class Session:
            def get(self,url,params,**kw):
                assert params['range']=='1d'
                class Response:
                    def raise_for_status(self):pass
                    def json(self):return {'chart':{'result':[{'meta':{'regularMarketPrice':101,'previousClose':100,'chartPreviousClose':80,'regularMarketTime':pd.Timestamp('2026-10-28T09:00:00+08:00').timestamp()}}]}}
                return Response()
        result=fetch_global('2026-10-28T10:00:00+08:00',Session())
        self.assertAlmostEqual(result.moves['nasdaq'],.01)


class ModelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory();root=Path(cls.temp.name);cls.store=MemoryStore(root)
        for k,f in generate(120,'2017-01-02','2023-12-29',seed=3).items():
            if not k.startswith('_'):cls.store.append(k,f)
        (root/'SYNTHETIC_DEMO_DATA').write_text('synthetic')
        cls.cfg=load_config(overrides={'research':{'start':'2019-01-01','holdout_months':6},'pools':{'sizes':[60,100],'rules':['ADV','KOSTO']}})
        cls.panel=build_panel(cls.store);cls.B=build_bundle(cls.panel,cls.cfg,log=lambda _:None)
    @classmethod
    def tearDownClass(cls):cls.temp.cleanup()
    def test_ten_lens_candidates_and_genuine_short_label(self):
        a=candidate_set(self.cfg,'short')
        self.assertEqual(set(LENSES),{p['ablation'] for p in a if 'ablation' in p})
        self.assertTrue(any(p['model'].get('label_horizon')=='short' for p in a));self.assertEqual(len(a),len({p['id'] for p in a}))
    def test_missing_and_redundant_weights_removed(self):
        rng=np.random.default_rng(4);x=rng.normal(size=(80,5));x[:,1]=x[:,0]
        w=regularize([.4,.3,.1,.1,.1],x,np.arange(60),[1,1,0,1,1])
        self.assertEqual(w[1],0);self.assertEqual(w[2],0);self.assertAlmostEqual(abs(w).sum(),1)
        self.assertLessEqual(max(abs(w)),.35+1e-9)
    def test_weight_regularisation_does_not_read_future(self):
        x=np.random.default_rng(7).normal(size=(100,5));a=regularize([1]*5,x,np.arange(50),[1]*5)
        x[50:,1]=x[50:,0];b=regularize([1]*5,x,np.arange(50),[1]*5)
        np.testing.assert_array_equal(a,b)
    def test_ten_lens_removal_survives_fixed_hypothesis_blends(self):
        p=next(p for p in candidate_set(self.cfg,'mid') if p.get('ablation')=='leadership');p['rule']='ADV';p['size']=60
        _,_,_,weights,history=_setup(self.B,self.cfg,p)
        for w in weights:
            if w is not None:
                for i,f in enumerate(self.B.factors):
                    if f in p['exclude']:self.assertEqual(w[i],0)
        self.assertTrue(history)
    def test_realistic_end_to_end_development_only(self):
        p=next(p for p in candidate_set(self.cfg,'mid') if p.get('regularized') and not p.get('exclude'));p['rule']='ADV';p['size']=60
        r=evaluate(self.B,self.cfg,p)
        self.assertTrue(r['synthetic']);self.assertGreaterEqual(r['metric']['fold_count'],3)
        self.assertLess(r['nav']['date'][-1],r['holdout_start'])
        self.assertTrue(all(x['from']<r['holdout_start'] for x in r['weights_history']))
    def test_insufficient_development_and_zero_benchmark_rejected(self):
        self.assertTrue(readiness(self.B,self.cfg)['ready'])
        cfg=copy.deepcopy(self.cfg);cfg['research']['train_min_months']=55
        self.assertFalse(readiness(self.B,cfg)['ready'])
        b=copy.deepcopy(self.B);b.a['BENCH'][:]=0;self.assertFalse(readiness(b,self.cfg)['ready'])
    def test_future_share_counts_are_not_backfilled(self):
        shares=self.panel['shares'];raw=self.store.read('shares');ticker=raw.ticker.iloc[0]
        first=raw.loc[raw.ticker.eq(ticker),'date'].min()
        if self.panel.info.loc[ticker,'board']=='TWSE':self.assertTrue(shares.loc[shares.index<first,ticker].isna().all())
    def test_missing_chip_inputs_never_create_observed_factors(self):
        from kosto.factors import compute
        panel=copy.deepcopy(self.panel)
        for key in ('foreign','trust','dealer','total','mbal','mlimit','sbal'):panel.m[key].iloc[:,:]=np.nan
        values,_=compute(panel,sample_idx=np.array([len(panel.dates)-1]))
        for name in ('c_foreign5','c_trust20','c_inst_streak','k_hands','k_paid','k_calm'):
            self.assertFalse(np.isfinite(values[name]).any(),name)


if __name__=='__main__':unittest.main(verbosity=2)
