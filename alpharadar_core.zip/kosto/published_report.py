"""Readable, portable report from the same publication the dashboard uses."""
import html,json
def render(p,status=None):
    e=lambda x:html.escape(str(x if x is not None else '待驗證'))
    def pct(v):return f'{v:+.1%}' if v is not None else '待驗證'
    table=''
    for h,m in p['models'].items():
        metric=m.get('metric',{});table+='<tr>'+''.join('<td>'+e(v)+'</td>' for v in [h,m['id'],m['label'],pct(metric.get('cagr')),pct(metric.get('bench_cagr')),pct(metric.get('mdd')),pct(metric.get('stress_excess'))])+'</tr>'
    weights=''
    for h,m in p['models'].items():
        weights+='<h3>'+e(h)+'</h3><pre>'+e(json.dumps(m.get('weights',{}),ensure_ascii=False,indent=2))+'</pre>'
    limits=''.join('<li>'+e(x)+'</li>' for x in p.get('research',{}).get('limitations',[]))
    intro='尚無本版完整真實歷史驗效，以下保持待驗證。' if p['state']=='initial_screen' else '以下為同一資料與成本、五種換股日平均的開發期樣本外結果；品質與前瞻成效仍須持續確認。'
    if p.get('synthetic'):intro='合成市場流程測試，不是真實投資績效。'+intro
    return '''<!doctype html><html lang="zh-Hant"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Alpha Radar V31 研究報告</title><style>body{background:#f1f5f8;color:#172e42;font:15px/1.9 -apple-system,"PingFang TC",sans-serif;margin:0}main{max-width:1060px;padding:35px;margin:25px auto;background:white;border-radius:15px}h1{letter-spacing:-1px}h2{font-size:21px;margin-top:30px}.lead{background:#e8f4ef;border-left:4px solid #168c79;padding:18px}.scroll{overflow:auto}table{border-collapse:collapse;width:100%;white-space:nowrap;font-size:12px}td,th{border-bottom:1px solid #e1e8ef;padding:12px;text-align:left}th{background:#f5f8fa}pre{background:#f4f7fa;padding:15px;white-space:pre-wrap;font-size:12px}small{color:#728797}@media(max-width:600px){main{padding:20px;margin:0}}@media print{body{background:white}main{margin:0}}</style><main><small>ALPHA RADAR / V31 CLOUD EDITION</small><h1>策略研究與持續驗效報告</h1><p>研究資料日 '''+e(p['research_date'])+'｜發布檔建立 '+e(p['published_at'])+'</p><div class="lead">'+e(intro)+'</div><h2>驗效結果</h2><div class="scroll"><table><tr><th>週期</th><th>模型</th><th>狀態</th><th>開發期淨年化</th><th>0050</th><th>回撤</th><th>成本壓力超額</th></tr>'+table+'''</table></div>
<h2>架構與更新方式</h2><p>GitHub Actions保存原始資料與可續跑進度、計算完整因子、比較模型並發布輕量成果。Streamlit只讀取名單、權重、績效及圖表；更新失敗保留上次成功結果。首次歷史建置仍需要時間，但只在背景工作執行，開站不重跑。</p>
<h2>候選與採用規則</h2><p>十個新訊號與原始因子組公平比較，包含MAX、彩券型特徵、偏態、營收驚喜與同業差、投信60日、外資持股高點、布林帶寬、自身本益比位置及同業殖利率。計算出來不代表必然有效。候選只使用開發期選型，預留期不參與挑選。</p><p>現行、領先者及輪替候選每日比較，週六擴大候選。超額至少多2個百分點、資訊比率不降、任一共同區段不退步逾5個百分點，連續10個不同交易日領先、冷卻20交易日後才切換。十日只是緩衝，不是十次獨立盲測。權重依1／3／6個月重估規則與回測一致；每天重新發布最新名單。</p>
<h2>實際模型權重</h2>'''+weights+'''<h2>公告後前瞻紀錄</h2><p>名單保存發布時間，不回填過去；發布後第一個可交易開盤才可模擬成交，漲停或停牌不成交，扣費稅滑價。顯示已到期等額批次淨報酬，非券商帳戶實績，也不冒充完整持倉組合年化。</p>
<h2>限制與資料口徑</h2><ul>'''+limits+'''<li>大盤法人金額為上市普通股淨買賣股數乘收盤價估計；融資是樣本張數加總，不是官方市場總額。</li><li>歷史曾被檢視的年份不再稱全新盲測。尚缺訓練資料的區間不填入假績效。</li><li>未連接並執行使用者GitHub前，不宣稱自動工作已部署或首次歷史驗證完成。</li></ul><h2>更新狀態</h2><pre>'''+e(json.dumps(status or {},ensure_ascii=False,indent=2,default=str))+'</pre></main></html>'
