"""Ten research lenses and train-only weight regularisation. No return promises."""
import numpy as np

LENSES={
 'growth':('營收成長',['f_rev_yoy','f_rev_yoy3','f_rev_accel','f_rev_streak','f_rev_high'],'比較持續成長與加速度，檢查低基期極端值'),
 'quality':('獲利品質',['f_roe','f_eps_yoy'],'現有歷史為估值推算代理，不能冒稱實際ROE或EPS成長'),
 'value':('估值',['f_ep','f_bp','f_dy'],'同業估值與便宜陷阱，排除負本益比'),
 'leadership':('相對強勢',['t_rs120','t_mom20','t_mom60','t_mom120x20'],'比較強勢延續；相關訊號避免重複加權'),
 'trend':('趨勢結構',['t_ma_align','t_above_ma60','t_high20','t_high252','t_kd','t_macd','t_rsi_health'],'短線轉折與中長趨勢分開測試'),
 'institutions':('法人買盤',['c_foreign5','c_foreign20','c_trust5','c_trust20','c_dealer5','c_inst60','c_inst_streak','c_inst2y'],'法人持續性與同步性；未公布日不填成買超'),
 'financing':('融資與持股',['c_margin_chg20','c_short_ratio','c_foreign_hold','k_paid','k_hands'],'融資擁擠及籌碼穩定；週資料不冒充當日主力'),
 'risk':('下行風險',['t_lowvol','t_lowidio','k_resilience'],'檢查波動、抗跌與成本壓力'),
 'liquidity':('流動性容量',['f_size','t_vol_surge','k_calm','k_vp'],'母池與實際成交容量共同限制，不能只選高分小股'),
 'behavior':('市場行為',['t_rev5','k_mw','k_egg'],'比較反轉、型態與市場階段，不預設一定有效')}


def lens_for(factor):
    extra={'t_max20':'risk','t_lottery20':'behavior','t_skew60':'risk','f_rev_surprise':'growth','f_rev_peer':'growth','c_trust60':'institutions','c_foreign_high':'financing','t_bb_squeeze':'trend','f_pe_own':'value','f_dy_peer':'value'}
    if factor in extra:return extra[factor]
    return next((key for key,(_,names,_) in LENSES.items() if factor in names),'behavior')


def regularize(w,ic,rows,coverage,excluded=(),factors=(),corr_limit=.85,cap=.35):
    """Prune redundant training IC, reject insufficient observations, then cap concentration.

    Only supplied matured training rows are read. At fewer than 3 usable factors,
    the feasible cap is disclosed by the weights rather than invented extra factors.
    """
    w=np.nan_to_num(np.asarray(w,float)).copy();coverage=np.asarray(coverage,float)
    w[(coverage<.6)|~np.isfinite(coverage)]=0
    for i,f in enumerate(factors):
        if f in excluded:w[i]=0
    selected=[];X=np.asarray(ic)[np.asarray(rows,int)]
    for j in np.argsort(-np.abs(w),kind='stable'):
        if not w[j]:continue
        duplicate=False
        for k in selected:
            ok=np.isfinite(X[:,j])&np.isfinite(X[:,k])
            if ok.sum()>=12 and X[ok,j].std()>1e-10 and X[ok,k].std()>1e-10:
                if abs(np.corrcoef(X[ok,j],X[ok,k])[0,1])>=corr_limit:duplicate=True;break
        if duplicate:w[j]=0
        else:selected.append(j)
    if not selected:return w
    signs=np.sign(w);a=np.abs(w);a/=a.sum();limit=max(cap,1/len(selected))
    for _ in range(100):
        over=a>limit+1e-12
        if not over.any():break
        excess=(a[over]-limit).sum();a[over]=limit;under=(a>0)&~over
        if not under.any():break
        a[under]+=excess*a[under]/a[under].sum()
    return a*signs


def training_coverage(B,view,rows):
    observations=[]
    for i in np.asarray(rows,int)[-52:]:
        idx=view.members[i]
        if len(idx):observations.append((B.a['U'][i,idx]>0).mean(axis=0))
    return np.mean(observations,axis=0) if observations else np.zeros(len(B.factors))
