"""Immutable published recommendations and conservative, explicitly simulated forward marks."""
import copy
import pandas as pd

def record(book,payload):
    book=copy.deepcopy(book or {'publications':[]});day=payload['research_date'];stamp=payload['published_at']
    if pd.Timestamp(stamp).tzinfo is None:raise ValueError('發布時間必須包含時區')
    for h,m in payload['models'].items():
        if any(x['day']==day and x['horizon']==h for x in book['publications']):continue
        book['publications'].append({'day':day,'horizon':h,'published_at':stamp,'model':m['id'],
            'days':{'short':5,'mid':20,'long':60}[h],'picks':[str(p['ticker']) for p in m['picks']],
            'status':'waiting','results':[]})
    return book

def mark(book,P,buy_cost=.001855,sell_cost=.004855):
    book=copy.deepcopy(book);dates=P.dates
    for item in book['publications']:
        if item.get('status')=='matured':continue
        stamp=pd.Timestamp(item['published_at']).tz_convert('Asia/Taipei')
        # A late publication cannot be retroactively filled at an earlier open.
        candidates=[i for i,d in enumerate(dates) if pd.Timestamp(d).tz_localize('Asia/Taipei')+pd.Timedelta(hours=9)>stamp and str(d.date())>item['day']]
        if not candidates:continue
        e=candidates[0];x=e+item['days']
        if x>=len(dates):item['status']='tracking';continue
        results=[]
        for t in item['picks']:
            if t not in P.tickers:results.append({'ticker':t,'status':'資料不足'});continue
            oc=P['oc'].iloc[e][t];gap=P['gap'].iloc[e][t]
            if not P['tradable'].iloc[e][t] or pd.isna(oc) or gap>=.095:
                results.append({'ticker':t,'status':'未成交','return':0.});continue
            exit_oc=P['oc'].iloc[x][t]
            if pd.isna(exit_oc) or not P['tradable'].iloc[x][t]:results.append({'ticker':t,'status':'到期開盤無成交，待核對'});continue
            growth=(1+P['ret'].iloc[e+1:x+1][t]).prod()
            ret=(1-buy_cost)*(1+oc)*growth/(1+exit_oc)*(1-sell_cost)-1
            results.append({'ticker':t,'status':'已到期','return':float(ret),'entry':str(dates[e].date()),'exit':str(dates[x].date())})
        item['results']=results
        item['status']='matured' if all('return' in r for r in results) and results else 'incomplete'
        item['net_return']=sum(r['return'] for r in results)/len(results) if item['status']=='matured' else None
    return book
