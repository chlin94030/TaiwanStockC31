"""Viewer-only Streamlit application. No download/build/research calls on this path."""
from __future__ import annotations
import html,json,os,base64
from dataclasses import replace
from pathlib import Path
from urllib.parse import quote
import numpy as np
import pandas as pd
import streamlit as st
from .published import PublishedClient,detect_repo
from .auto_quotes import QuoteHub
from .desk_quotes import phase,taipei,quote_check
from .desk_plan import TradePlan,decision,PROFILES,allocation,signal_current
from . import ta

ROOT=Path(os.getenv('ALPHA_DESK_PROJECT_ROOT',Path(__file__).resolve().parent.parent))
H={'short':'短線 · 5日','mid':'中線 · 20日','long':'長線 · 60日'}
E=lambda x:html.escape(str(x if x is not None else '—'))
def num(x,d=1):
    try:return f'{float(x):,.{d}f}' if np.isfinite(float(x)) else '—'
    except (ValueError,TypeError):return '—'
def pct(x):return num(x*100,1)+'%' if x is not None and np.isfinite(x) else '待驗證'
def secret(name):
    try:return str(st.secrets.get(name,os.getenv(name,'')))
    except Exception:return os.getenv(name,'')

STYLE='''<style>
:root{--ink:#14283d;--muted:#718298;--teal:#087f79;--line:#dfe7ef;--panel:#fff}.stApp{background:#f1f5f8;color:var(--ink)}
html,body,button,input,.stMarkdown{font-family:Inter,-apple-system,"PingFang TC","Noto Sans TC","Microsoft JhengHei",sans-serif;font-variant-numeric:tabular-nums}
.block-container{max-width:1240px;padding-top:2rem;padding-bottom:4rem}[data-testid=stHeader]{background:transparent;height:1.6rem}[data-testid=stToolbar]{display:none}
h1,h2,h3{color:var(--ink);letter-spacing:-.035em}.mast{display:flex;align-items:center;justify-content:space-between;padding:18px 0;border-bottom:2px solid #162c45;gap:14px}.brand{font-size:21px;font-weight:850;letter-spacing:1.7px}.brand b{color:var(--teal)}.brand small{display:block;font-size:10px;color:var(--muted);letter-spacing:1.2px;font-weight:500;margin-top:4px}.edition{font-size:10px;letter-spacing:1.1px;color:var(--muted);text-align:right}
.statusbar{display:flex;gap:16px;align-items:center;flex-wrap:wrap;background:#fff;border:1px solid var(--line);border-radius:10px;padding:11px 15px;margin:13px 0 8px;font-size:12px}.statusbar b{font-size:14px}.statusbar a{color:inherit;text-decoration:none}.dot{width:7px;height:7px;border-radius:50%;display:inline-block;margin-right:5px;background:#94a3b8}.dot.ok{background:#0a9b77}.dot.run{background:#dfa841}.dot.fail{background:#d55055}.muted{color:var(--muted)}
.hero{background:linear-gradient(115deg,#122a43,#1b4b58);padding:18px 24px;border-radius:15px;margin:14px 0 20px;color:white}.hero small{color:#83d6c5;letter-spacing:2px;font-size:10px}.hero h1{font-size:29px;color:white;margin:7px 0 4px;padding:0}.hero p{color:#c6dce4;font-size:13px;line-height:1.7;margin:7px 0 0}
.cards{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin:12px 0 20px}.pick{display:block;position:relative;text-decoration:none!important;color:var(--ink)!important;background:#fff;border:1px solid var(--line);border-radius:13px;padding:18px 20px;box-shadow:0 5px 18px #17374b04;transition:.15s}.pick:hover{border-color:#42a99e;box-shadow:0 8px 22px #17374b0c;transform:translateY(-1px)}.row{display:flex;justify-content:space-between;gap:12px;align-items:center}.rank{color:var(--teal);font-size:11px;font-weight:700;letter-spacing:.8px}.stockname{font-size:22px;font-weight:750;letter-spacing:-.5px;margin:7px 0 2px}.stockname small{font-size:12px;font-weight:450;color:var(--muted);margin-left:9px}.sector{font-size:11px;color:var(--muted)}.px{font-size:24px;font-weight:700;text-align:right}.px small{font-size:10px;color:var(--muted);display:block;font-weight:400}.pill{font-size:10px;background:#edf5f5;color:#258379;padding:4px 8px;border-radius:18px;white-space:nowrap}.why{font-size:12px;line-height:1.7;margin:13px 0 12px;color:#506579;min-height:20px}.levels{display:grid;grid-template-columns:1.6fr 1fr 1fr;border-top:1px solid #edf1f5;padding-top:12px;gap:7px}.levels span{display:block;color:var(--muted);font-size:9px;margin-bottom:3px}.levels b{font-size:13px;font-weight:650}.tiny{font-size:10px;color:var(--muted);line-height:1.7}.helpbar{padding:15px 20px;background:#e6f2ef;border:1px solid #c9e4dc;border-radius:10px;font-size:12px;line-height:1.9;color:#34685c;margin:17px 0}.rule{border-top:1px solid var(--line);padding-top:14px;margin-top:25px;color:var(--muted);font-size:10px;line-height:1.8}
[data-testid=stMetric]{background:white;border:1px solid var(--line);border-radius:10px;padding:12px 15px}[data-testid=stMetricValue]{font-size:24px}[data-testid=stExpander]{background:white;border-radius:10px;border:1px solid var(--line)}.stButton button{border-radius:8px}.st-key-mainnav div[role=radiogroup]{gap:10px;width:100%;padding:10px 0}.st-key-mainnav label{flex:1 1 0!important;min-width:0;width:50%;white-space:nowrap;padding:13px 18px;border:1px solid var(--line);border-radius:10px;background:white}.st-key-mainnav label:has(input:checked){background:#e8f3f1;border-color:#16877c}.st-key-mainnav label p{font-weight:650}.empty{background:white;border:1px dashed #bdcedb;padding:25px;border-radius:12px;margin:15px 0;color:#678094}
@media(max-width:700px){.block-container{padding:1rem .8rem 4rem}.brand{font-size:17px}.edition{font-size:8px;max-width:125px}.mast{padding:10px 0 14px}.statusbar{gap:8px 13px;font-size:10px;padding:10px}.statusbar b{font-size:12px}.hero{padding:17px}.hero h1{font-size:25px}.hero p{font-size:12px}.cards{grid-template-columns:1fr;gap:10px}.pick{padding:15px 17px}.stockname{font-size:21px}.px{font-size:23px}.why{margin:11px 0 9px}.levels b{font-size:12px}.st-key-mainnav label{padding:11px 9px}.st-key-mainnav label p{font-size:13px}[data-testid=stMetricValue]{font-size:20px}.helpbar{padding:13px 16px}.hide-mobile{display:none}.st-key-desk_controls [data-testid=stHorizontalBlock],.st-key-reading_controls [data-testid=stHorizontalBlock]{flex-direction:row!important;gap:8px!important}.st-key-desk_controls [data-testid=stColumn],.st-key-reading_controls [data-testid=stColumn]{min-width:0!important;flex:1 1 45%!important;width:45%!important}.st-key-summary_metrics [data-testid=stHorizontalBlock]{flex-direction:row!important;gap:8px!important}.st-key-summary_metrics [data-testid=stColumn]{min-width:0!important;flex:1 1 30%!important;width:30%!important}.st-key-summary_metrics [data-testid=stMetric]{padding:9px}.st-key-summary_metrics [data-testid=stMetricValue]{font-size:17px}}
</style>'''
_font=Path(__file__).with_name('data')/'inter-latin.woff2'
if _font.exists():STYLE+='<style>@font-face{font-family:Inter;font-style:normal;font-weight:100 900;font-display:swap;unicode-range:U+0000-024F,U+2000-206F,U+20A0-20CF;src:url(data:font/woff2;base64,'+base64.b64encode(_font.read_bytes()).decode()+') format("woff2")}</style>'
_tc=Path(__file__).with_name('data')/'radar-tc.woff2'
if _tc.exists():STYLE+='<style>@font-face{font-family:"Radar TC";font-style:normal;font-weight:100 900;font-display:swap;unicode-range:U+2E80-9FFF,U+F900-FAFF,U+FF00-FFEF;src:url(data:font/woff2;base64,'+base64.b64encode(_tc.read_bytes()).decode()+') format("woff2")}html,body,.stApp,.stApp :not([data-testid="stIconMaterial"]):not([data-testid="stIconEmoji"]){font-family:Inter,"Radar TC",-apple-system,"PingFang TC","Noto Sans TC","Microsoft JhengHei",sans-serif!important}.stApp [data-testid="stIconMaterial"]{font-family:"Material Symbols Rounded"!important}</style>'

@st.cache_resource(show_spinner=False)
def client(root,repo,token):return PublishedClient(root,repo,token)
@st.cache_resource(show_spinner=False)
def quotes():return QuoteHub()
@st.cache_resource(show_spinner=False)
def overseas():
    from .market_context import MarketContext
    return MarketContext()

def header(c,p,q):
    st.markdown('<div class="mast"><div class="brand">ALPHA <b>RADAR</b><small>INVESTMENT DESK / 投資決策台</small></div><div class="edition">V31 · CLOUD EDITION<br>研究在雲端完成，打開直接閱讀</div></div>',unsafe_allow_html=True)
    runs=c.status.get('runs',[]);r=runs[0] if runs else {};state=r.get('status');result=r.get('conclusion')
    label,kind=('更新中','run') if state and state!='completed' else ('上次更新成功','ok') if result=='success' else ('上次更新失敗','fail') if result else ('更新狀態待確認','')
    pipeline=c.status.get('pipeline',{})
    if pipeline.get('stage')=='backfill':label,kind='歷史資料建置中','run'
    if pipeline.get('stage')=='source_stalled':label,kind='來源停滯，查看診斷','fail'
    day=p['research_date'];index=q.get('t00') or {};date=index.get('date') or p.get('market_date',day)
    close=index.get('price');line=f'最新行情 <b>{E(date)}</b>'
    if close and np.isfinite(close):line=f'加權 <b>{num(close,0)}</b> <span class="muted">{E(date)} {E(index.get("time",""))}</span>'
    # Use actual market dates; weekends are not automatically labelled stale.
    try:
        gap=max(0,len(pd.bdate_range(day,date))-1)
        stale=f'<span style="color:#b94b53">研究落後約{gap}交易日</span>' if gap>1 else ''
    except ValueError:stale=''
    url=r.get('html_url') or (f'https://github.com/{c.repo}/actions' if c.repo else '')
    status=f'<span><i class="dot {kind}"></i>{label}</span>'
    if url:status=f'<a href="{E(url)}" target="_blank" rel="noopener">{status} ↗</a>'
    st.markdown(f'<div class="statusbar"><span>研究資料日 <b>{E(day)}</b></span><span>{line}</span>{status}{stale}</div>',unsafe_allow_html=True)
    context=overseas().get(enabled=os.getenv('ALPHA_RADAR_OFFLINE_QA')!='1') or p.get('global')
    if context:
        names={'sox':'費半','nasdaq':'Nasdaq','nq_fut':'美股期貨','nikkei':'日經','kospi':'韓股'}
        parts=[f'{names[k]} <b>{pct(v)}</b>' for k,v in context.get('moves',{}).items() if k in names]
        st.markdown('<div class="tiny">'+'　 '.join(parts)+'　｜海外執行參考，未改動已發布模型排名</div>',unsafe_allow_html=True)

def plan_obj(raw):
    if not raw:return None
    try:return TradePlan(**raw)
    except (TypeError,ValueError):return None

def action(pick,stock,h,q,mode,p):
    plan=plan_obj(stock.get('plans',{}).get(h))
    role='none' if pick is None else 'keep' if pick.get('role')=='hold' else 'pick'
    out=decision(plan,q,role=role,mode='live' if mode=='盤中確認' else 'close',data_ready=p['state']=='research' and signal_current(p['research_date']) and stock.get('price_date',stock.get('asof'))==p['research_date'],
                    synthetic=p.get('synthetic',False))
    return replace(out,label='價位符合・研究候選') if out.can_enter and not p['models'][h].get('certified') else out

def spark(chart):
    values=[v for v in (chart or {}).get('close',[])[-50:] if v is not None]
    if len(values)<10:return ''
    lo,hi=min(values),max(values);den=hi-lo or 1
    points=' '.join(f'{i*110/(len(values)-1):.1f},{26-(v-lo)*23/den:.1f}' for i,v in enumerate(values))
    return f'<svg class="hide-mobile" width="112" height="30" viewBox="0 0 112 30"><polyline points="{points}" fill="none" stroke="#138e82" stroke-width="1.4"/></svg>'

def recommendations(c,p,h,mode,q):
    m=p['models'][h]
    heading='本期觀察清單'
    st.markdown('<div class="hero"><small>01 / TODAY’S SELECTION</small><h1>'+H[h]+'｜'+heading+'</h1><p>入選理由、買進參考區與防守價一次看清。點選個股開啟完整分析。</p></div>',unsafe_allow_html=True)
    with st.container(key='summary_metrics'):
        a,b,d=st.columns(3);a.metric('本期觀察',f'{len(m["picks"])} 檔');b.metric('本期策略','啟動初選' if p['state']=='initial_screen' else f'精簡{m["recipe"]["model"]["k"]}因子');d.metric('因子平均涵蓋',f'{np.mean([x["coverage"] for x in m["picks"]]):.0%}' if m['picks'] else '—')
    if p['state']=='initial_screen':st.caption('啟動初選・未驗效；首次雲端研究完成後自動替換。')
    with st.container(key='reading_controls'):
        a,b=st.columns([2,1]);view=a.selectbox('閱讀方式',['精選清單','完整總表'],label_visibility='collapsed')
        live=b.toggle('盤中確認',value=mode=='盤中確認',key='live_mode');mode='盤中確認' if live else '盤後規劃'
    cards=[];table=[]
    for pick in m['picks']:
        t=pick['ticker'];s=p['stocks'][t];plan=s.get('plans',{}).get(h);valid=q.get(t) and quote_check(q[t])[0]
        px=q[t]['price'] if valid else s['close'];a=action(pick,s,h,q.get(t),mode,p)
        buy=f'{num(plan["buy_low"])}–{num(plan["buy_high"])}' if plan else '待資料完整'
        stop=num(plan['alert']) if plan else '—';why='、'.join(pick.get('reasons',[])[:2]) or '綜合排序入選'
        href='?stock='+quote(t,safe='')+'&h='+h
        cards.append(f'<a class="pick" href="{href}" target="_self"><div class="row"><span class="rank">{pick["rank"]:02d} / 優先觀察</span><span class="pill">{E(a.label)}</span></div><div class="row"><div><div class="stockname">{E(s["name"])}<small>{E(t)}</small></div><div class="sector">{E(s["group"])}</div></div><div class="px">{num(px)}<small>{"即時有效成交" if valid else "最近收盤參考"}</small></div></div><div class="row"><div class="why">{E(why)}</div>{spark(p.get("charts",{}).get(t))}</div><div class="levels"><div><span>買進參考區</span><b>{E(buy)}</b></div><div><span>防守參考</span><b>{E(stop)}</b></div><div><span>因子涵蓋</span><b>{pick["coverage"]:.0%}</b></div></div></a>')
        table.append({'股票':t+' '+s['name'],'族群':s['group'],'狀態':a.label,'參考價':px,'買區':buy,'防守':stop,'涵蓋':f'{pick["coverage"]:.0%}','入選理由':why})
    if view=='精選清單':st.markdown('<div class="cards">'+''.join(cards)+'</div>',unsafe_allow_html=True)
    else:st.dataframe(pd.DataFrame(table),hide_index=True,width='stretch')
    st.markdown('<div class="helpbar"><b>盤後：</b>用名單安排下一交易日觀察與限價。　<b>盤中：</b>確認有效成交、買區與防守，再評估分批投入。<br>價位規則尚未與策略回測完全整合；研究分數不是勝率，0050 可不配置。</div>',unsafe_allow_html=True)
    with st.expander('配置資金與部位上限'):capital(p)

def capital(p):
    amount=st.number_input('可用資金（元）',min_value=10000,value=1000000,step=10000)
    profile=st.selectbox('配置方式',list(PROFILES),index=list(PROFILES).index('純個股均衡'))
    weights=PROFILES[profile];st.caption('0050 選配；單股最多10%、同族群個股25%、單股至防守價風險預算0.5%。尚未扣除你的既有持倉。')
    st.caption('研究績效使用模型標準持倉；自選配比與價位操作不等同該回測組合。')
    selections={h:[x['ticker'] for x in m['picks']] for h,m in p['models'].items()};plans={};prices={};groups={}
    for h,ts in selections.items():
        for t in ts:
            s=p['stocks'][t];plan=plan_obj(s['plans'].get(h))
            if plan and (t not in plans or plan.alert>plans[t].alert):plans[t]=plan;prices[t]=plan.entry;groups[t]=s['group']
    rows,ledger=allocation(amount,weights,selections,plans,prices,top_k=8,groups=groups)
    st.write(f'個股預算含費用 {num(ledger["stocks_including_fees"],0)} 元；0050 {num(ledger["etf"],0)} 元；保留現金 {num(ledger["cash"],0)} 元。')
    if not rows.empty:st.dataframe(rows,hide_index=True,width='stretch')
    else:st.info('目前沒有足夠技術價位可試算股數，保留預算。')

def to_frame(data):
    if not data or not data.get('date'):return pd.DataFrame()
    return pd.DataFrame({k:v for k,v in data.items() if k!='date'},index=pd.to_datetime(data['date']))

def plot_frame(f,key,index=False):
    if f.empty:st.info('已發布檔目前沒有這段圖表，不以合成K線補圖。');return
    a,b=st.columns([1,2]);period=a.selectbox('K線期間',['D','W','M'],format_func={'D':'日K','W':'週K','M':'月K'}.get,key=key+'per')
    panels=b.multiselect('顯示指標',['volume','kd','macd','rsi','inst','margin','holders'],default=['volume'],
        format_func={'volume':'成交金額' if index else '成交量','kd':'KD','macd':'MACD','rsi':'RSI','inst':'法人','margin':'資券','holders':'大戶'}.get,key=key+'pan')
    mas=st.multiselect('日均線',['5','20','60','120','240'],default=['20','60'],format_func=lambda x:{'5':'週線','20':'月線','60':'季線','120':'半年線','240':'年線'}[x],key=key+'ma')
    boll=st.checkbox('布林通道',value=False,key=key+'boll')
    if not {'open','high','low','close'}.issubset(f.columns):st.line_chart(f[['close']]);return
    if index:f=f.copy();f['volume']=f['amount']/1e8 if 'amount' in f else np.nan
    f=ta.indicators(ta.resample(f,period))
    from .charts import kline
    fig=kline(f,mas=[int(x) for x in mas],boll=boll,panels=panels,bars=180,dark=False,ma_unit=period)
    if index:
        for trace in fig.data:
            if trace.name=='成交量(張)':trace.name='成交金額(億元)'
            if trace.name and '(張)' in trace.name and any(x in trace.name for x in ['外資','投信','自營商']):trace.name=trace.name.replace('(張)','估計金額(億元)')
        for axis in fig.select_yaxes():
            if axis.title.text=='成交量':axis.title.text='成交金額(億元)'
    st.plotly_chart(fig,width='stretch')

def stock(c,p,t,h,q):
    s=p['stocks'][t]
    if st.button('← 返回推薦清單'):st.query_params.pop('stock',None);st.rerun()
    st.markdown(f'<div class="hero"><small>STOCK / 個股診斷</small><h1>{E(s["name"])} <span style="font-size:18px">{E(t)}</span></h1><p>{E(s["group"])}　研究資料日 {E(p["research_date"])}</p></div>',unsafe_allow_html=True)
    pick=next((x for x in p['models'][h]['picks'] if x['ticker']==t),None)
    @st.fragment(run_every='5s' if os.getenv('ALPHA_RADAR_OFFLINE_QA')!='1' else None)
    def verdict():
        live=quotes().get([s],enabled=os.getenv('ALPHA_RADAR_OFFLINE_QA')!='1')
        d=action(pick,s,h,live.get(t),'盤中確認' if phase()=='盤中' else '盤後規劃',p);st.info(d.label+'｜'+d.reason)
        a,b,dcol=st.columns(3);valid=live.get(t) and quote_check(live[t])[0]
        a.metric('有效成交' if valid else '最近收盤',num(live[t]['price'] if valid else s['close']));plan=s['plans'].get(h)
        b.metric('買進參考區',f'{num(plan["buy_low"])}–{num(plan["buy_high"])}' if plan else '待資料完整');dcol.metric('防守參考',num(plan['alert']) if plan else '待確認')
    verdict()
    if pick:st.write('入選原因：'+'、'.join(pick['reasons']))
    else:st.caption('目前不在本週期的新買名單；沒有名次不等於公司不存在。')
    fundamentals=s.get('fundamentals',{})
    with st.expander('營收、EPS與估值',expanded=True):
        a,b,d=st.columns(3);a.metric('月營收年增',num(fundamentals.get('revenue_yoy_pct'))+'%' if fundamentals.get('revenue_yoy_pct') is not None else '待來源')
        b.metric('本益比',num(fundamentals.get('pe')));d.metric('EPS（元）',num(fundamentals.get('eps'),2))
        st.caption('營收月份 '+str(fundamentals.get('revenue_date') or '最近已公布')+'；財報期間 '+str(fundamentals.get('period') or '待來源')+'。估值推算代理與季報原始數字分開呈現。')
    try:
        with st.spinner('讀取這檔個股的圖表分片…'):data=c.stock_chart(t)
        f=to_frame(data)
    except Exception:f=pd.DataFrame();st.caption('圖表暫未取得，保留已發布的模型資訊。')
    plot_frame(f,'stock-'+t)
    if len(f):
        cols=[x for x in ['foreign','trust','dealer','mbal','sbal','big400','big1000'] if x in f and f[x].notna().any()]
        if cols:st.dataframe(f[cols].tail(5),width='stretch')
        st.caption('法人為已公布日資料（張）；資券為餘額（張）；大戶為週資料持股比例，不是當日主力進出。主力分點尚未接入。')
    with st.expander('三週期名次、權重與基本面觀測'):
        st.write({H[k]:s['ranks'].get(k) for k in H});st.json(s.get('factors',{}));st.caption('ROE、EPS成長若由估值推算，屬代理訊號；並非最新季報原始值。')

def tracking(p):
    book=p.get('forward',{}).get('publications',[])
    st.subheader('公告後，照原名單持續追蹤')
    st.caption('發布時間、名單與模型識別一經保存不回填修改。這是每日名單等額批次模擬，扣費稅滑價；不是券商實際成交或完整組合年化。')
    rows=[{'名單日':r['day'],'週期':H[r['horizon']],'狀態':r['status'],'檔數':len(r['picks']),'批次淨報酬':pct(r.get('net_return')),'發布時間':r['published_at']} for r in book[-100:]]
    if rows:st.dataframe(pd.DataFrame(rows).iloc[::-1],hide_index=True,width='stretch')
    else:st.info('尚未累積本版公告後紀錄。第一次成功發布起才開始，不把歷史回測當前瞻績效。')

def market(p):
    st.subheader('加權指數與市場廣度');f=to_frame(p.get('index'))
    plot_frame(f,'index',index=True)
    st.caption('法人金額為上市普通股買賣超股數 × 收盤價的估算（億元）；融資為樣本張數加總。均不是證交所官方市場總額。')
    if len(f) and {'breadth_up','breadth_down'}<=set(f):st.line_chart(f[['breadth_up','breadth_down']].tail(100).rename(columns={'breadth_up':'上漲家數','breadth_down':'下跌家數'}))

def laboratory(c,p):
    st.markdown('<div class="hero"><small>02 / MODEL EVIDENCE</small><h1>策略驗效與模型管理</h1><p>閱讀已發布的績效、因子權重與挑戰者結果，追蹤公告後表現。</p></div>',unsafe_allow_html=True)
    section=st.segmented_control('研究專區',['驗效總覽','因子與挑戰者','前瞻紀錄','更新狀態與報告'],default='驗效總覽') or '驗效總覽'
    if section=='驗效總覽':
        rows=[]
        for h,m in p['models'].items():
            x=m.get('metric',{});rows.append({'週期':H[h],'模型':m['label'],'開發期淨年化':pct(x.get('cagr')),'同期0050':pct(x.get('bench_cagr')),'超額':pct(x.get('excess_cagr')),'最大回撤':pct(x.get('mdd')),'成本壓力超額':pct(x.get('stress_excess'))})
        st.dataframe(pd.DataFrame(rows),hide_index=True,width='stretch')
        st.caption('五種換股日等額平均；這些是開發期樣本外研究結果。預留期間不參與挑選；曾反覆看過的2018／2019–2020不稱新盲測，無足夠訓練資料時保持待測。')
        h=st.selectbox('查看淨值',list(H),format_func=H.get);curve=p['models'][h].get('curve',{})
        if curve.get('date'):st.line_chart(pd.DataFrame({'模型':curve['strategy'],'0050':curve['benchmark']},index=pd.to_datetime(curve['date'])))
        else:st.info('尚無本版真實歷史研究結果，待第一次 Actions 研究完成後自動呈現。')
    elif section=='因子與挑戰者':
        h=st.selectbox('研究週期',list(H),format_func=H.get);m=p['models'][h];leader=p.get('promotion',{}).get('leaders',{}).get(h)
        a,b=st.columns(2);a.metric('現行模型',m['id'][:12]);b.metric('領先挑戰者',f'{leader["streak"]}/10 交易日' if leader else '尚無連續領先者')
        st.caption('每日比較現行、領先者與輪替候選；週六擴大搜尋。超額至少多2個百分點、IR不降、各區段不退步逾5個百分點；連續10個不同交易日領先、距前次切換至少20交易日才換上。這些是緩衝門檻，非十次獨立顯著性證明。')
        weights=m.get('weights',{})
        if weights:
            from .model_policy import lens_for,LENSES
            st.dataframe(pd.DataFrame([{'面向':LENSES[lens_for(f)][0],'因子':f,'目前權重':f'{v:+.1%}'} for f,v in weights.items()]).sort_values('面向'),hide_index=True,width='stretch')
            st.caption('權重重估日 '+str(m.get('weight_date'))+'；每日更新名單，權重依冠軍1／3／6個月重估設定，和回測保持一致。')
        with st.expander('完整因子IC／ICIR與觀測涵蓋'):
            if m.get('factor_diagnostics'):st.dataframe(pd.DataFrame(m['factor_diagnostics']),hide_index=True,width='stretch')
            else:st.caption('首次歷史研究完成後提供，不以啟動快照推估歷史IC。')
            st.caption('此處是本次權重訓練期診斷，不是獨立樣本外績效。')
        result=p.get('research',{}).get('results',{}).get(h,[])
        if result:st.dataframe(pd.DataFrame([{'候選':r['id'],'檔數':r['recipe'].get('top_k'),'因子組':r['recipe'].get('features'),'重估月數':r['recipe'].get('retrain_months'),'開發期淨年化':pct(r['metric'].get('cagr')),'IR':num(r['metric'].get('info_ratio'),2),'可列冠軍':r.get('eligible')} for r in result]),hide_index=True,width='stretch')
        with st.expander('模型鎖定與回復'):
            st.caption('管理操作由 GitHub 執行並留下紀錄；選 action=lock／unlock／rollback 及對應 horizon。回復後先鎖定，避免自動換回。')
            if c.repo:st.link_button('開啟模型管理工作流程',f'https://github.com/{c.repo}/actions/workflows/pipeline.yml')
        with st.expander('模型切換紀錄'):
            history=p.get('promotion',{}).get('history',[])
            if history:st.dataframe(pd.DataFrame([{k:x.get(k) for k in ('date','horizon','from','to','reason')} for x in history[-30:]]),hide_index=True,width='stretch')
            else:st.caption('目前沒有切換紀錄。')
    elif section=='前瞻紀錄':tracking(p)
    else:
        status=c.status.get('pipeline',{});st.write(c.status.get('message'))
        candidate=status.get('candidate',{})
        if candidate.get('total'):
            st.progress(min(1.,candidate['done']/candidate['total']),text=f'{H.get(candidate["horizon"],candidate["horizon"])}：候選{candidate["done"]}/{candidate["total"]} × 5換股日')
            if candidate.get('error'):st.caption('此候選失敗已記錄：'+str(candidate['error']))
        if status.get('tables'):st.dataframe(pd.DataFrame(status['tables']),hide_index=True,width='stretch')
        for group,v in status.get('groups',{}).items():st.progress(min(1.,max(0.,v)),text=f'{group}：{v:.1%}')
        if c.repo:st.link_button('查看 GitHub 執行進度與錯誤',f'https://github.com/{c.repo}/actions')
        if not c.repo:st.info('尚未辨識本儲存庫；請在Secrets填入 ALPHARADAR_REPO="帳號/儲存庫"，或確認部署的GitHub來源。')
        with st.expander('一次設定自動更新工作流程'):
            st.caption('V30只有市場快照流程；升級V31必須更新一次 .github/workflows/pipeline.yml。之後開站沿用此流程，不在網站建庫。')
            workflow=ROOT/'pipeline_workflow_COPY.txt'
            if workflow.exists():st.code(workflow.read_text(),language='yaml')
            if c.repo:st.link_button('前往更新工作流程檔',f'https://github.com/{c.repo}/edit/main/.github/workflows/pipeline.yml')
        st.download_button('下載完整已發布研究資料',json.dumps(p,ensure_ascii=False,indent=2),'AlphaRadar_V31_Published_Research.json','application/json')
        from .published_report import render
        st.download_button('下載研究報告',render(p,c.status),'AlphaRadar_V31_Research_Report.html','text/html',type='primary')
        for line in p.get('research',{}).get('limitations',[]):st.caption('・'+line)

def main():
    st.set_page_config(page_title='Alpha Radar｜選股決策台',page_icon='◈',layout='wide');st.markdown(STYLE,unsafe_allow_html=True)
    c=client(str(ROOT),secret('ALPHARADAR_REPO') or secret('GITHUB_REPO'),secret('GITHUB_TOKEN'));offline=os.getenv('ALPHA_RADAR_OFFLINE_QA')=='1'
    if not offline:c.refresh()
    p=c.payload
    if p is None:st.error('尚無有效發布檔；請查看 GitHub 工作流程，網站不會自行重建資料庫。');return
    chosen=st.query_params.get('h','mid');h=chosen if chosen in H else 'mid'
    unique={x['ticker'] for m in p['models'].values() for x in m['picks']}
    all_stocks=[{'ticker':'t00','board':'TWSE'}]+[p['stocks'][t] for t in unique]
    @st.fragment(run_every='5s' if not offline else None)
    def live_header():
        if not offline:c.refresh()
        if c.payload is not p:st.rerun()
        header(c,p,quotes().get(all_stocks,enabled=not offline))
    live_header();q=quotes().get(all_stocks,enabled=False)
    if p.get('synthetic'):st.warning('合成資料測試｜不是真實投資績效')
    section=st.radio('主要區塊',['選股儀表板','模型研究與驗效'],horizontal=True,label_visibility='collapsed',key='mainnav',width='stretch')
    if section=='模型研究與驗效':laboratory(c,p);return
    with st.container(key='desk_controls'):
        a,b=st.columns([1,1]);h=a.selectbox('操作期間',list(H),format_func=H.get,index=list(H).index(h),label_visibility='collapsed')
        search=b.text_input('查詢個股',placeholder='代號／公司名稱',label_visibility='collapsed')
    t=st.query_params.get('stock','')
    if search:
        t=next((t for t,s in p['stocks'].items() if search.strip() in (t+' '+s['name'])),'')
        if not t:st.caption('本期發布母池沒有符合的代號或名稱。')
    if t in p['stocks']:stock(c,p,t,h,q);return
    sub=st.segmented_control('看盤工作區',['推薦清單','持股追蹤','大盤'],default='推薦清單',label_visibility='collapsed') or '推薦清單'
    if sub=='持股追蹤':tracking(p)
    elif sub=='大盤':market(p)
    else:
        mode='盤中確認' if phase()=='盤中' else '盤後規劃'
        @st.fragment(run_every='5s' if not offline else None)
        def live_board():
            if not offline:c.refresh()
            if c.payload is not p:st.rerun()
            quotes_now=quotes().get([{'ticker':'t00','board':'TWSE'}]+[p['stocks'][x['ticker']] for x in p['models'][h]['picks']],enabled=not offline)
            recommendations(c,p,h,mode,quotes_now)
        live_board()
    st.markdown('<div class="rule">ALPHA RADAR V31 · 研究與行情分開標示日期 · 每5秒為報價排程，上游成交時間另行核對 · 不自動下單</div>',unsafe_allow_html=True)

if __name__=='__main__':main()
