"""Optional asynchronous overseas context; never changes published ranks."""
import threading,time
from dataclasses import asdict
from .global_markets import fetch_global
class MarketContext:
    def __init__(self):self.value=None;self.running=False;self.last=-1e9
    def get(self,enabled=True):
        if enabled and not self.running and time.monotonic()-self.last>=300:
            self.running=True;self.last=time.monotonic()
            def work():
                try:
                    snap=fetch_global()
                    if snap.available_weight>0:self.value=asdict(snap)
                finally:self.running=False
            threading.Thread(target=work,daemon=True,name='overseas-context').start()
        return self.value
