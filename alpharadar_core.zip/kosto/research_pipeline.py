"""Incremental interactive pipeline. A batch budget covers ALL groups, not each one."""
from pathlib import Path
import time
import pandas as pd
from .config import load_config
from .store import Store
from .build import Builder,progress
from .sources.official import FetchInterrupted

LABELS={'price':'歷史價量','institutional':'三大法人','margin':'融資融券','valuation':'歷史估值','misc':'營收與企業行動'}


def pipeline_config(root):
    return load_config(overrides={'data':{'dir':str(Path(root)/'data'),'latest_first':True,'max_retries':2,'request_slice_sec':8}})


def inventory(cfg):
    store=Store(cfg['data']['dir']);summary=store.summary().to_dict('records')
    return {'tables':summary,'download':progress(cfg)}


def recent_segment(prices):
    """Keep the latest contiguous segment; 2017 + 2026 snapshots are not nine years."""
    if prices.empty:return prices
    days=pd.DatetimeIndex(sorted(prices.date.unique()))
    gaps=(days[1:]-days[:-1]).days
    breaks=[i+1 for i,v in enumerate(gaps) if v>20]
    start=days[breaks[-1]] if breaks else days[0]
    return prices.loc[prices.date>=start]


def run_batch(root,stop_event,update,budget_minutes=5,builder_cls=Builder):
    cfg=pipeline_config(root);deadline=time.time()+budget_minutes*60
    update(status='背景建置研究資料',phase='download',done=0,total=5,group_done=0,
           message='近期往回連續補齊；上市／上櫃輪流，每日保存，不刪除既有資料。')
    reports={};logs=[];last_inventory=0
    for index,(group,fraction) in enumerate([('price',.45),('institutional',.12),('margin',.12),('valuation',.12),('misc',.19)]):
        if stop_event.is_set() or time.time()>=deadline:break
        group_deadline=min(deadline,time.time()+max(3,budget_minutes*60*fraction))
        def event(**e):
            update(group=group,group_done=index,done=e.pop('done',0),total=e.pop('total',0),**e)
        def log(message):
            logs.append(str(message));update(message=str(message),logs=logs[-20:])
        update(group=group,group_done=index,done=0,total=0,message=LABELS[group]+'：準備日期清單')
        try:
            reports[group]=builder_cls(cfg,group,budget_minutes=max(.01,(group_deadline-time.time())/60),
                log=log,event=event,stop_event=stop_event).run()
        except FetchInterrupted:pass
        except Exception as exc:
            reports[group]={'error':str(exc)};log(LABELS[group]+'暫未完成：'+str(exc))
        try:
            data=inventory(cfg);last_inventory=time.time()
            update(inventory=data,reports=reports,group_done=index+1)
        except Exception as exc:log('資料盤點暫未完成：'+str(exc))
    if not last_inventory:update(inventory=inventory(cfg))
    if stop_event.is_set():update(status='資料建置已暫停',message='已取得的每日資料與日期進度已保存。');return None
    store=Store(cfg['data']['dir']);price=recent_segment(store.read('price'))
    if price.empty:
        update(status='來源暫無可用價量',message='請展開來源診斷；下批重試未完成日期，不記成休市。');return None
    days=pd.DatetimeIndex(sorted(price.date.unique()));span=(days[-1]-days[0]).days/365.25
    update(price_days=len(days),price_from=str(days[0].date()),price_to=str(days[-1].date()),
           phase='saved',done=len(days),total=None)
    if span<5.5 or len(days)/max(span,1)<200:
        update(status='本批已保存，可繼續補齊',message=f'近期連續價量 {len(days)} 個交易日（{days[0]:%Y-%m-%d}～{days[-1]:%Y-%m-%d}）。圖表可先使用；完整時序驗效仍需暖機、訓練、開發及保留期。')
        return None
    # Do not rebuild an unchanged price/factor store every minute.
    files=list((Path(cfg['data']['dir'])/'raw').rglob('*.parquet'))
    stamp=tuple(sorted((str(p),p.stat().st_mtime_ns) for p in files))
    return cfg,price,stamp
