"""Build a small dashboard plus optional chart shards from a completed worker bundle."""
import gzip,json
from pathlib import Path
import numpy as np
import pandas as pd
from .auto_market import safe
from .published import now,digest,encode,atomic
from .cloud_research import latest,recipes
from .desk_plan import build_plan
from .chain import label

def compact(value):return gzip.compress(json.dumps(safe(value),ensure_ascii=False,allow_nan=False,separators=(',',':')).encode(),mtime=0)

def frame(B,j):
    names={'Q_O':'open','Q_H':'high','Q_L':'low','Q_C':'close','Q_V':'volume','Q_FI':'foreign','Q_TR':'trust','Q_DL':'dealer','Q_MB':'mbal','Q_SB':'sbal','Q_H400':'big400','Q_H1000':'big1000'}
    return pd.DataFrame({name:B.a[key][:,j] for key,name in names.items() if key in B.a},index=pd.DatetimeIndex(B.meta['q_days']))

def chart(f):
    return {'date':[str(d.date()) for d in f.index],**{k:[round(float(x),4) if np.isfinite(x) else None for x in f[k]] for k in f}}

def build(B,P,state,results,book,root,index_frame=None):
    day=str(B.sig_dates[-1].date());stock={};charts={};models={};universe={}
    for h in ('short','mid','long'):
        champ=state.get('champions',{}).get(h);row=next((r for r in results[h] if champ and r['id']==champ['id']),None)
        if row is None:
            valid=[r for r in results[h] if not r.get('error') and np.isfinite(r['metric'].get('cagr',np.nan))]
            if not valid:raise ValueError(h+'尚無有效完成候選，不覆蓋前次發布')
            row=max(valid,key=lambda r:r['metric']['cagr'])
        if row.get('error'):raise ValueError(h+'現行冠軍未完成本次研究，不發布混用模型')
        recipe=row['recipe'];days={'short':5,'mid':20,'long':60}[h]
        prior_day=str(B.sig_dates[-days-1].date()) if len(B.sig_dates)>days else ''
        prior=next((x['picks'] for x in book.get('publications',[]) if x['day']==prior_day and x['horizon']==h),[])
        data=latest(B,recipe,prior)
        universe[h]=data['ranks']
        models[h]={'id':recipe['id'],'asof':day,'label':'研究冠軍' if champ else '研究候選・尚未通過門檻',
            'certified':False,'recipe':recipe,'picks':data['picks'],'weights':data['weights'],'weight_date':data['weight_date'],
            'metric':row['metric'],'curve':row['curve'],'phase_excess':row['phase_excess'],'stage':data['stage'],'factor_diagnostics':data['diagnostics'],
            'checks':{'five_offsets':True,'eligible':row['eligible'],'source_quality_verified':False}}
    selected={p['ticker'] for m in models.values() for p in m['picks']}
    for j,t in enumerate(B.tickers):
        chain=label(t,B.meta['sectors'][j]);f=frame(B,j).dropna(subset=['close']);plans={}
        for h in models:
            p=build_plan(f,h) if len(f)>=60 and str(f.index[-1].date())==day and f[['open','high','low','close']].notna().all(axis=1).sum()>=60 else None
            plans[h]=p.as_dict() if p else None
        values={name:float(B.a['LATEST_RAW'][j,k]) for k,name in enumerate(B.factors) if np.isfinite(B.a['LATEST_RAW'][j,k])}
        stock[t]={'ticker':t,'name':B.meta['names'][j],'board':B.meta['boards'][j],'group':chain['group'],
            'sector':B.meta['sectors'][j],'close':float(f.close.iloc[-1]) if len(f) else None,
            'asof':day,'price_date':str(f.index[-1].date()) if len(f) else None,'plans':plans,'ranks':{h:universe[h].get(t) for h in models},'factors':values}
        stock[t]['fundamentals']={'revenue_yoy_pct':values.get('f_rev_yoy',np.nan)*100,
            'pe':1/values['f_ep'] if values.get('f_ep',0)>0 else None,'eps':None,'period':'季報原始EPS尚未接入完整歷史'}
        charts[t]=chart(f.tail(500))
    for t in P.tickers:
        if t in stock:continue
        f=pd.DataFrame({k:P[k][t] for k in ('open','high','low','close','volume')}).dropna(subset=['close']).tail(500)
        if f.empty:continue
        f['volume']=f['volume']/1000;meta=P.info.loc[t];chain=label(t,meta['sector'])
        stock[t]={'ticker':t,'name':meta['name'],'board':meta['board'],'group':chain['group'],'sector':meta['sector'],
            'close':float(f.close.iloc[-1]),'asof':day,'price_date':str(f.index[-1].date()),
            'plans':{h:None for h in models},'ranks':{h:None for h in models},'factors':{}}
        charts[t]=chart(f)
    index=index_frame.copy() if index_frame is not None else pd.DataFrame()
    if not index.empty:
        index=index.set_index('date').sort_index().loc[lambda x:x.index<=pd.Timestamp(day)].tail(500)
        cols=P.info.index[P.info.board.eq('TWSE')]
        for col in ('foreign','trust','dealer'):
            # Close-price estimate on observed listed common stocks, not official cash totals.
            x=(P[col][cols]*P['close'][cols]).sum(axis=1,min_count=max(1,int(len(cols)*.8)))/1e8
            index[col]=x.reindex(index.index)
        index['mbal']=P['mbal'][cols].sum(axis=1,min_count=max(1,int(len(cols)*.8))).reindex(index.index)
        index['breadth_up']=(P['ret'][cols]>0).where(P['tradable'][cols]).sum(axis=1,min_count=1).reindex(index.index)
        index['breadth_down']=(P['ret'][cols]<0).where(P['tradable'][cols]).sum(axis=1,min_count=1).reindex(index.index)
    payload={'schema':1,'version':'31.0.0','published_at':now(),'research_date':day,'market_date':day,
        'synthetic':bool(B.meta.get('synthetic')),'state':'research','models':models,'stocks':stock,
        'charts':{t:charts[t] for t in selected},'index':chart(index[[c for c in index if c!='ticker']]) if len(index) else {},
        'calendar':[str(d.date()) for d in P.dates],'promotion':state,'forward':book,
        'research':{'results':{h:[{k:v for k,v in r.items() if k!='curve'} for r in rows] for h,rows in results.items()},
            'limitations':['保留期未參與候選選型；反覆看過的期間不稱全新盲測。','十日領先是切換緩衝，並非十次獨立統計證明。',
              '毛利率、營益率、現金流與借券餘額尚無完整PIT資料，未冒充已納入。','同業分類為可得產業名冊，歷史產業改分類尚未全面核實。',
              '前瞻為發布後每日名單等額批次模擬，非使用者券商帳戶或完整重疊持倉績效。'],
            'data_identity':B.meta['data_identity']},'chart_shards':{}}
    out=Path(root)/'artifacts';out.mkdir(exist_ok=True);files=[]
    for digit in '0123456789':
        part={t:c for t,c in charts.items() if t[-1]==digit};raw=compact(part);sha=digest(raw);name=f'charts-{digit}-{sha}.json.gz'
        atomic(out/name,raw);files.append(out/name);payload['chart_shards'][digit]={'asset':name,'sha256':sha}
    return safe(payload),files

def initial(market):
    models={};stocks={};date=max(str(p['date'])[:10] for p in market.payload['price'])
    for h in ('short','mid','long'):
        rows=market.picks(h);picks=[]
        for r in rows.to_dict('records'):
            t=r['ticker'];stocks.setdefault(t,{'ticker':t,'name':r['name'],'board':r['board'],'group':r['group'],'sector':r['sector'],
                'close':r['price'],'asof':r['date'],'plans':{k:None for k in ('short','mid','long')},'ranks':{},'factors':{},
                'fundamentals':{'revenue_yoy_pct':r.get('revenue_yoy'),'revenue_mom_pct':r.get('revenue_mom'),'revenue_date':r.get('revenue_date'),
                    'pe':r.get('pe'),'pb':r.get('pb'),'eps':r.get('eps'),'period':r.get('quality_period')}})
            stocks[t]['ranks'][h]=r['rank']
            if r['eligible'] and len(picks)<8:picks.append({'ticker':t,'rank':len(picks)+1,'score':r['score'],'coverage':r['coverage'],'reasons':r['reasons'].split('、')})
        models[h]={'id':'initial-'+h,'asof':date,'picks':picks,'label':'初選觀察・未驗效','certified':False,'weights':{},'weight_date':None,'metric':{},'curve':{},'recipe':{},'stage':'UNKNOWN'}
    return safe({'schema':1,'version':'31.0.0','published_at':now(),'research_date':date,'market_date':date,'state':'initial_screen','synthetic':False,
        'models':models,'stocks':stocks,'charts':{},'index':{},'calendar':[],'promotion':{},'forward':{'publications':[]},
        'research':{'results':{},'limitations':['啟動快照提供初選，首次GitHub研究完成後自動替換；目前沒有本版真實歷史績效。']},'chart_shards':{}})
