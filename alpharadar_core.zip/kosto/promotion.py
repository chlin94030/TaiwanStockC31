"""Champion/challenger state. Persistence is hysteresis, not ten independent tests."""
import copy,math

def finite(v):return isinstance(v,(int,float)) and math.isfinite(v)

def beats(challenger,current,min_gain=.02,max_fold_loss=.05):
    if not challenger.get('eligible') or challenger.get('window')!=current.get('window'):return False
    a,b=challenger['metric'],current['metric']
    if any(not finite(x.get(k)) for x in (a,b) for k in ('cagr','excess_cagr','info_ratio')):return False
    if a['excess_cagr']<b['excess_cagr']+min_gain or a['info_ratio']<b['info_ratio']:return False
    af,bf=challenger.get('folds',{}),current.get('folds',{})
    if set(af)!=set(bf) or len(af)<3:return False
    if any(not finite(af[k]) or not finite(bf[k]) or af[k]<bf[k]-max_fold_loss for k in af):return False
    return challenger.get('offset_count')==5 and current.get('offset_count')==5

def advance(previous,day,calendar,results,auto=True,streak_days=10,cooldown=20):
    state=copy.deepcopy(previous or {'champions':{},'leaders':{},'history':[],'locks':{}})
    for key,empty in (('champions',{}),('leaders',{}),('history',[]),('locks',{})):
        state.setdefault(key,copy.deepcopy(empty))
    # A retry or a rerun of the same close never creates another day of evidence.
    if state.get('evaluated_date','')>=day:return state
    sessions=sorted({d for d in calendar if d<=day});prior=sessions[-2] if len(sessions)>1 else None
    for h,rows in results.items():
        byid={r['id']:r for r in rows};current=state['champions'].get(h)
        usable=[r for r in rows if r.get('eligible') and not r.get('synthetic')]
        if not current:
            if usable:
                win=max(usable,key=lambda r:r['metric']['cagr'])
                state['champions'][h]={'id':win['id'],'recipe':win['recipe'],'since':day,'certified':False}
                state['history'].append({'date':day,'horizon':h,'from':None,'to':win['id'],'reason':'首次研究冠軍，品質證據未齊不稱正式驗效'})
            continue
        base=byid.get(current['id'])
        if not base:
            state['leaders'][h]=None;continue
        contenders=[r for r in usable if r['id']!=current['id'] and beats(r,base)]
        best=max(contenders,key=lambda r:r['metric']['cagr']) if contenders else None
        old=state['leaders'].get(h) or {}
        if best:
            n=old.get('streak',0)+1 if old.get('id')==best['id'] and state.get('evaluated_date')==prior else 1
            state['leaders'][h]={'id':best['id'],'recipe':best['recipe'],'streak':n,'date':day,
                                 'gain':best['metric']['excess_cagr']-base['metric']['excess_cagr']}
            elapsed=sum(current['since']<d<=day for d in sessions)
            if auto and not state['locks'].get(h) and n>=streak_days and elapsed>=cooldown:
                state['history'].append({'date':day,'horizon':h,'from':current['id'],'to':best['id'],
                    'previous':copy.deepcopy(current),'reason':'連續領先及冷卻期通過；研究冠軍切換，非獨立盲測證明'})
                state['champions'][h]={'id':best['id'],'recipe':best['recipe'],'since':day,'certified':False}
                state['leaders'][h]=None
        else:state['leaders'][h]=None
    state['evaluated_date']=day;return state

def control(previous,h,action,day):
    state=copy.deepcopy(previous)
    if action in ('lock','unlock'):state.setdefault('locks',{})[h]=action=='lock'
    elif action=='rollback':
        old=next((x for x in reversed(state.get('history',[])) if x['horizon']==h and x.get('previous')),None)
        if not old:raise ValueError('尚無可回復的已發布冠軍')
        current=state['champions'][h];restored=copy.deepcopy(old['previous']);restored['since']=day
        state['champions'][h]=restored;state.setdefault('locks',{})[h]=True
        state['history'].append({'date':day,'horizon':h,'from':current['id'],'to':restored['id'],'reason':'手動回復並鎖定'})
    else:raise ValueError('不支援的模型操作')
    state['leaders'][h]=None;return state
