"""GitHub worker commands. No worker is started by the Streamlit entry point."""
import argparse,copy,gzip,hashlib,json,os,sqlite3,tarfile,time
from pathlib import Path
import pandas as pd
from .published import GitHub,DATA_TAG,STATE_TAG,LIVE_TAG,atomic,encode,decode,now
from .config import load_config
from .store import Store,GROUPS

def log(message):print(now()+' '+str(message),flush=True)
def config():return load_config(overrides={'data':{'latest_first':True}})
def github():return GitHub(os.environ['GITHUB_REPOSITORY'],os.getenv('GH_TOKEN') or os.getenv('GITHUB_TOKEN'))
def write_json(path,value):
    from .auto_market import safe
    atomic(Path(path),json.dumps(safe(value),ensure_ascii=False,allow_nan=False,indent=1).encode())

def restore(group):
    from .remote import unpack
    g=github();name='data-'+group+'.tar.gz';path=Path('artifacts')/name
    found=False
    for tag in (DATA_TAG,'kosto-data'):
        if g.download(tag,name,path):unpack('data',path);found=True;log(f'沿用 {tag}/{name}');break
    Path('artifacts').mkdir(exist_ok=True)
    Path('artifacts/.restored-'+group).write_text('restored' if found else 'first-build')

def update(group,budget):
    from .build import Builder
    cfg=config()
    if group=='misc':
        from .index_data import update as update_index
        from .sources.official import Http,today_tw
        from .sources.official import FetchInterrupted
        try:update_index(Store('data','misc'),Http(2.6,2,deadline=time.time()+min(600,budget*15),log=log),cfg['data']['start'],today_tw(),log)
        except FetchInterrupted:log('大盤歷史本批保存，下一輪續跑')
    rep=Builder(cfg,group,token=os.getenv('FINMIND_TOKEN',''),budget_minutes=budget,log=log,
        event=lambda **x:log(f"{x.get('dataset','')} {x.get('board','')} {x.get('date','')} {x.get('done',0)}/{x.get('total',0)} 已存{x.get('rows',0):,}筆")).run()
    write_json(Path('artifacts')/f'update-{group}.json',rep)

def checkpoint(group):
    from .remote import pack
    if not Path('artifacts/.restored-'+group).exists():raise RuntimeError('未成功確認既有檢查點，拒絕覆蓋')
    out=Path('artifacts')/('data-'+group+'.tar.gz');pack('data',group,str(out));github().upload(DATA_TAG,out,replace=True)

def restore_all():
    for group in GROUPS:restore(group)
    path=Path('artifacts/research-state.tar.gz')
    if github().download(STATE_TAG,path.name,path):
        from .remote import unpack
        unpack('artifacts',path)
    Path('artifacts/.state-restored').write_text('ready')
    # Recover the last actual publication if a state upload failed after publishing.
    from .published import MARKER
    from .forward_book import record
    g=github();rel=g.release(LIVE_TAG)
    if rel and str(rel.get('body','')).startswith(MARKER):
        try:
            m=json.loads(rel['body'][len(MARKER):]);asset=next(x for x in rel['assets'] if x['name']==m['asset'])
            content=g.asset(asset)
            if hashlib.sha256(content).hexdigest()!=m['sha256']:raise ValueError('發布驗證失敗')
            p=decode(content);p['published_at']=rel.get('updated_at',p['published_at'])
            book=load('forward_book.json',{'publications':[]});write_json('artifacts/forward_book.json',record(book,p))
        except Exception as exc:log('前次公告復原暫未完成：'+type(exc).__name__)

def load(name,default):
    p=Path('artifacts')/name
    return json.loads(p.read_text()) if p.exists() else copy.deepcopy(default)

def save_state():
    Path('artifacts').mkdir(exist_ok=True)
    if not Path('artifacts/.state-restored').exists():raise RuntimeError('上次模型狀態未成功確認，拒絕以空狀態覆蓋')
    db=Path('artifacts/strategy_lab.sqlite');backup=Path('artifacts/registry.backup.sqlite')
    if db.exists():
        with sqlite3.connect(db) as source,sqlite3.connect(backup) as dest:source.backup(dest)
    out=Path('artifacts/research-state.tar.gz')
    with tarfile.open(out,'w:gz') as tar:
        for name in ('cloud_state.json','forward_book.json','registry.backup.sqlite'):
            p=Path('artifacts')/name
            if p.exists():tar.add(p,arcname='strategy_lab.sqlite' if name=='registry.backup.sqlite' else name)
    github().upload(STATE_TAG,out,replace=True)

def readiness(cfg):
    from .research_pipeline import recent_segment
    prices=recent_segment(Store(cfg['data']['dir']).read('price'))
    if prices.empty:return False,'尚無歷史價量',None
    days=pd.DatetimeIndex(sorted(prices.date.unique()));span=(days[-1]-days[0]).days/365.25
    ready=span>=5.5 and len(days)/max(span,1)>=200
    if ready:
        for ds in ('institutional','margin','valuation'):
            f=Store(cfg['data']['dir']).read(ds)
            coverage=len(set(pd.to_datetime(f.date))&set(days))/len(days) if not f.empty else 0
            if coverage<.7:return False,f'{ds}歷史日期覆蓋{coverage:.0%}，先續補，保留既有推薦',prices
        rv=Store(cfg['data']['dir']).read('revenue')
        if rv.empty or rv.ym.nunique()<48:return False,'營收歷史尚未滿48個月，先續補',prices
    return ready,f'近期連續價量 {len(days):,}日，{days[0]:%Y-%m-%d}～{days[-1]:%Y-%m-%d}',prices

def finish(full=False,budget=6,action='run',horizon='mid',data_only=False):
    cfg=config();store=Store('data');ok,reason,prices=readiness(cfg)
    from .build import progress
    status=progress(cfg);status.update(message=reason,updated_at=now(),stage='researching' if ok else 'backfill',
        tables=store.summary().to_dict('records'),research_ready=ok,
        run_url=f"https://github.com/{os.environ['GITHUB_REPOSITORY']}/actions/runs/{os.getenv('GITHUB_RUN_ID','')}")
    g=github();rel=g.release('alpharadar-status',True)
    try:old_status=json.loads(rel.get('body') or '{}')
    except ValueError:old_status={}
    total_rows=sum(r['rows'] for r in status['tables']);status['total_rows']=total_rows
    status['advanced']=total_rows>old_status.get('total_rows',0) or status['percent']>old_status.get('percent',0)
    if not ok and not status['advanced']:status['stage']='source_stalled'
    g.api('releases/'+str(rel['id']),'PATCH',json={'body':json.dumps(status,ensure_ascii=False,default=str)})
    if os.getenv('GITHUB_OUTPUT'):
        with open(os.environ['GITHUB_OUTPUT'],'a') as f:f.write('continue='+str(not ok and status['advanced']).lower()+'\n')
    previous=load('cloud_state.json',{'champions':{},'leaders':{},'history':[],'locks':{}})
    if action!='run':
        from .promotion import control
        if action=='rollback' and not ok:raise ValueError('回復模型需要既有研究資料，尚未更動發布名單')
        previous=control(previous,horizon,action,now()[:10])
        # Preserve the current published result; only its administrative state changes.
        from .published import MARKER
        live=g.release(LIVE_TAG)
        if action!='rollback' and live and str(live.get('body','')).startswith(MARKER):
            m=json.loads(live['body'][len(MARKER):]);a=next(x for x in live['assets'] if x['name']==m['asset']);p=decode(g.asset(a));p['promotion']=previous
            write=Path('artifacts/dashboard.json.gz');atomic(write,encode(p));g.publish(write,{'code_commit':os.getenv('GITHUB_SHA','')})
        if action!='rollback':write_json('artifacts/cloud_state.json',previous);return
    if not ok or data_only:
        log(reason+'；保留最近一次成功的推薦，不在網頁重建資料庫')
        if os.getenv('GITHUB_OUTPUT'):
            with open(os.environ['GITHUB_OUTPUT'],'a') as f:f.write('research_ready=false\n')
        return
    from .panel import build_panel
    from .bundle import build_bundle
    from .cloud_research import daily_tournament,recipes
    from .promotion import advance
    from .publication_builder import build
    from .forward_book import mark,record
    cfg['research']['signal_step']=1
    cfg['research']['start']=str(max(pd.Timestamp(cfg['research']['start']),prices.date.min()+pd.Timedelta(days=365)).date())
    log('一次計算每日因子矩陣，再切成五種換股日；不重複下載五次')
    P=build_panel(store,start=prices.date.min());B=build_bundle(P,cfg,log=log)
    h=hashlib.sha256()
    for file in sorted(Path('data/raw').rglob('*.parquet')):
        h.update(str(file.relative_to('data')).encode())
        with file.open('rb') as f:
            for block in iter(lambda:f.read(4*1024*1024),b''):h.update(block)
    B.meta['data_identity']=h.hexdigest()
    def candidate_progress(h,done,total,result):
        status['candidate']={'horizon':h,'done':done,'total':total,'id':result['id'],'error':result.get('error')}
        status['updated_at']=now()
        try:g.api('releases/'+str(rel['id']),'PATCH',json={'body':json.dumps(status,ensure_ascii=False,default=str)})
        except Exception:log('進度狀態暫未寫回；本地候選結果已保存')
    results=daily_tournament(B,Path.cwd(),previous,full,log,budget,event=candidate_progress)
    day=str(B.sig_dates[-1].date());calendar=[str(d.date()) for d in P.dates]
    state=advance(previous,day,calendar,results,auto=os.getenv('AUTO_PROMOTE','true').lower()=='true')
    if full:
        state['watchlist']={h:max((r for r in rows if r.get('eligible')),key=lambda r:r['metric']['cagr'],default={}) for h,rows in results.items()}
    book=mark(load('forward_book.json',{'publications':[]}),P)
    payload,shards=build(B,P,state,results,book,Path.cwd(),store.read('index'))
    for file in shards:g.upload(LIVE_TAG,file)
    out=Path('artifacts/dashboard.json.gz');atomic(out,encode(payload))
    manifest=g.publish(out,{'code_commit':os.getenv('GITHUB_SHA',''),'run_url':status['run_url']})
    payload['published_at']=manifest['announced_at'];book=record(book,payload)
    write_json('artifacts/cloud_state.json',state);write_json('artifacts/forward_book.json',book)
    status.update(stage='published',research_date=day,published_at=manifest['announced_at'])
    g.api('releases/'+str(rel['id']),'PATCH',json={'body':json.dumps(status,ensure_ascii=False,default=str)})
    if os.getenv('GITHUB_OUTPUT'):
        with open(os.environ['GITHUB_OUTPUT'],'a') as f:f.write('research_ready=true\n')
    log('發布完成：'+day+'；Streamlit僅需輕量成果檔')

def main(argv=None):
    p=argparse.ArgumentParser();p.add_argument('phase',choices=['restore','update','checkpoint','restore-all','finish','save-state','check'])
    p.add_argument('--group',choices=list(GROUPS));p.add_argument('--budget',type=float,default=80);p.add_argument('--candidates',type=int,default=6)
    p.add_argument('--full',action='store_true');p.add_argument('--action',default='run',choices=['run','lock','unlock','rollback']);p.add_argument('--horizon',default='mid',choices=['short','mid','long'])
    p.add_argument('--data-only',action='store_true')
    a=p.parse_args(argv)
    if a.phase=='check':
        import pytest
        return pytest.main(['-q',str(Path(__file__).resolve().parents[1]/'tests')])
    if a.phase=='restore':restore(a.group)
    elif a.phase=='update':update(a.group,a.budget)
    elif a.phase=='checkpoint':checkpoint(a.group)
    elif a.phase=='restore-all':restore_all()
    elif a.phase=='finish':finish(a.full,a.candidates,a.action,a.horizon,a.data_only)
    else:save_state()
