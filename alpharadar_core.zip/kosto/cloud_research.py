"""Compute factors once per day; compare five trading-day offsets without five downloads."""
import copy,json,os
import numpy as np
import pandas as pd
from .bundle import Bundle
from .strategy_lab import _setup,digest,development_metrics,Registry
from .backtest import run,choose,market_stage
from .metrics import perf
from dataclasses import replace

SIGNAL_AXIS0=('U','FWD_UNUSED','STAGE','DTOP','WSUP','TRADE','CAP','CLOSE','MCAP','RSI14','BIAS20','MKT')

def offset_bundle(B,offset,step=5):
    if B.meta['config']['research']['signal_step']!=1:raise ValueError('換股日比較需要一次計算的每日訊號包')
    # Anchor to the first trading date, not the latest date; appending a day cannot shift old phases.
    ids=np.flatnonzero(B.sig_pos%step==offset)
    if not len(ids):raise ValueError('缺少此換股日樣本')
    meta=copy.deepcopy(B.meta);meta['sig_dates']=[B.meta['sig_dates'][i] for i in ids];meta['sig_pos']=B.sig_pos[ids].tolist()
    meta['config']['research']['signal_step']=step
    arrays=dict(B.a)
    for k in SIGNAL_AXIS0:
        if k in arrays:arrays[k]=arrays[k][ids]
    arrays['FWD']=B.a['FWD'][:,ids];arrays['RANKS']=B.a['RANKS'][:,ids]
    return Bundle(meta,arrays)

def recipes(cfg,h):
    base=copy.deepcopy(cfg['horizons'][h]['model']);out=[]
    # A small fixed daily tournament, enlarged on Saturdays. No unbounded parameter fishing.
    for rule,size in [('BLEND',300),('ADV',300),('MCAP',500)]:
        for k,months,features in [(3,1,'core'),(5,3,'core'),(5,1,'expanded'),(8,3,'expanded')]:
            m={**base,'mode':'sparse','k':k,'tmin':1 if h=='long' else 2}
            p={'horizon':h,'rule':rule,'size':size,'model':m,'top_k':8,'retrain_months':months,
               'features':features,'weighting':'equal','prior_blend':0.,'regularized':True,
               'hysteresis':2.5,'residual':'cash','family':'V31'}
            p['id']=digest(p)[:18];out.append(p)
    for n in (6,10):
        p=copy.deepcopy(out[2]);p['top_k']=n;p.pop('id');p['id']=digest(p)[:18];out.append(p)
    for months in (6,):
        p=copy.deepcopy(out[2]);p['retrain_months']=months;p.pop('id');p['id']=digest(p)[:18];out.append(p)
    for cap in (2,3):
        p=copy.deepcopy(out[2]);p['max_per_sector']=cap;p.pop('id');p['id']=digest(p)[:18];out.append(p)
    for hysteresis in (1.5,2.):
        p=copy.deepcopy(out[2]);p['hysteresis']=hysteresis;p.pop('id');p['id']=digest(p)[:18];out.append(p)
    # Diagnose ten lenses using the same expanded recipe.
    from .model_policy import LENSES,lens_for
    from .extra_factors import NAMES
    for key,(_,factors,_) in LENSES.items():
        p=copy.deepcopy(out[2]);p['exclude']=list(factors)+[f for f in NAMES if lens_for(f)==key]
        p['ablation']=key;p.pop('id');p['id']=digest(p)[:18];out.append(p)
    if h=='short':
        p=copy.deepcopy(out[2]);p['model'].update(label_horizon='short',growth_blend=0.,hyp_blend=0.)
        p.pop('id');p['id']=digest(p)[:18];out.append(p)
    return out

def evaluate(B,recipe):
    navs=[];benches=[];stresses=[];boundaries=[]
    for offset in range(5):
        b=offset_bundle(B,offset);cfg=copy.deepcopy(b.meta['config']);cfg['research']['signal_step']=5
        R,v,rule,W,_=_setup(b,cfg,recipe);boundary=b.sig_dates[min(R.holdout,len(b.sig_dates)-1)];boundaries.append(boundary)
        # Candidate selection cannot inspect held-out performance.
        W=[w if i<R.holdout else None for i,w in enumerate(W)];spec=R.spec(recipe['horizon'],v);view=R.view(rule,recipe['size'])
        result=run(b,view,W,spec,start_i=R.first_oos)
        stress=run(b,view,W,replace(spec,buy_cost=spec.buy_cost+.0025,sell_cost=spec.sell_cost+.0025),start_i=R.first_oos)
        navs.append(result.nav);benches.append(result.bench);stresses.append(stress.nav)
    boundary=min(boundaries)
    def align(items):
        frame=pd.concat(items,axis=1,join='inner').loc[lambda x:x.index<boundary]
        frame=frame.div(frame.iloc[0]);return frame.mean(axis=1)
    nav,bench,stress=align(navs),align(benches),align(stresses)
    m,folds,_,_=development_metrics(nav,bench,boundary)
    m['stress_excess']=perf(stress,bench).get('excess_cagr')
    phases=[perf(n.loc[n.index.isin(nav.index)],b).get('excess_cagr') for n,b in zip(navs,benches)]
    m['phase_positive']=int(sum(x is not None and x>0 for x in phases))
    eligible=bool(m.get('mdd',-1)>=-.45 and m.get('fold_count',0)>=3 and m['phase_positive']>=3 and
        (m.get('fold_win_rate') or 0)>=.5 and (m.get('stress_excess') or -1)>0)
    return {'id':recipe['id'],'recipe':recipe,'metric':m,'offset_count':5,'phase_excess':phases,
       'window':f'{nav.index[0]:%Y-%m-%d}:{nav.index[-1]:%Y-%m-%d}',
       'folds':{x['from']+':'+x['to']:x['excess_cagr'] for x in folds},'eligible':eligible,
       'synthetic':bool(B.meta.get('synthetic')),
       'curve':{'date':[str(d.date()) for d in nav.index],'strategy':nav.tolist(),'benchmark':bench.tolist()}}

def daily_tournament(B,root,previous,full=False,log=print,budget=6,event=None):
    state=Registry(root);date=str(B.sig_dates[-1].date());study=digest({'data':B.meta['data_identity'],'v':'V31','code':os.getenv('GITHUB_SHA','local')})
    results={};session=len(B.sig_dates)
    for h in ('short','mid','long'):
        available=recipes(B.meta['config'],h);old=previous.get('champions',{}).get(h) or {};leader=previous.get('leaders',{}).get(h) or {}
        selected=available if full else [available[(session+i)%len(available)] for i in range(max(1,budget-2))]
        for item in (old,leader,previous.get('watchlist',{}).get(h) or {}):
            if item.get('recipe'):selected.insert(0,item['recipe'])
        if not old: selected.insert(0,available[2])
        selected=list({r['id']:r for r in selected}.values());results[h]=[]
        cached={r['id']:r for r in state.rows(study,h)}
        for i,recipe in enumerate(selected):
            log(f'{h}：{i+1}/{len(selected)} 候選 × 5換股日，{recipe["id"]}')
            result=cached.get(recipe['id'])
            if result is None:
                try:result=evaluate(B,recipe)
                except (ValueError,KeyError,np.linalg.LinAlgError) as exc:
                    result={'id':recipe['id'],'recipe':recipe,'metric':{},'folds':{},'curve':{},'phase_excess':[],
                        'offset_count':0,'eligible':False,'synthetic':bool(B.meta.get('synthetic')),'error':str(exc)}
                result['created_at']=date;state.save(study,h,result)
            results[h].append(result)
            if event:event(h,i+1,len(selected),result)
    return results

def latest(B,recipe,previous_picks=()):
    cfg=copy.deepcopy(B.meta['config']);cfg['research']['signal_step']=1
    R,v,rule,W,history=_setup(B,cfg,recipe);view=R.view(rule,recipe['size']);w=W[-1]
    if w is None:return {'picks':[],'weights':{},'ranks':{},'diagnostics':[],'weight_date':None,'stage':market_stage(B,len(B.sig_dates)-1)}
    prev=[B.tickers.index(t) for t in previous_picks if t in B.tickers]
    picks,_,scores=choose(B,view,len(B.sig_dates)-1,w,prev,R.spec(recipe['horizon'],v))
    percentile=pd.Series(scores).rank(pct=True)*100;ranks=pd.Series(scores).rank(ascending=False,method='min');out=[]
    from .research import factor_phrase
    for j in picks:
        position=int(np.flatnonzero(view.members[-1]==j)[0]);z=view.Z[-1][position];contrib=z*w
        positive=[int(f) for f in np.argsort(-contrib) if contrib[f]>0][:3]
        out.append({'ticker':B.tickers[j],'rank':len(out)+1,'score':float(percentile[j]),
            'role':'hold' if j in prev and int(ranks[j])>recipe.get('top_k',8) else 'candidate',
            'coverage':float(((B.a['U'][-1,j]>0)*np.abs(w)).sum()/np.abs(w).sum()),
            'reasons':[factor_phrase(B,f,z[f]) for f in positive]})
    hz=v.label_h or recipe['horizon'];fit_point=int(B.sig_dates.searchsorted(history[-1]['from']));rows=R.train_rows(fit_point,hz)
    ic=R.ic(rule,recipe['size'],hz)[rows];diagnostics=[]
    from .model_policy import training_coverage,lens_for
    coverage=training_coverage(B,view,rows)
    for j,f in enumerate(B.factors):
        x=ic[:,j];x=x[np.isfinite(x)]
        diagnostics.append({'factor':f,'name':B.meta['factor_zh'][j],'dimension':lens_for(f),'n':len(x),
            'ic':float(x.mean()) if len(x) else None,'icir':float(x.mean()/x.std()) if len(x)>1 and x.std()>0 else None,'coverage':float(coverage[j]),'weight':float(w[j])})
    return {'picks':out,'weights':{f:float(x) for f,x in zip(B.factors,w) if abs(x)>1e-8},
            'ranks':{B.tickers[int(j)]:int(r) for j,r in ranks.items()},'diagnostics':diagnostics,
            'weight_date':history[-1]['from'] if history else None,'stage':market_stage(B,len(B.sig_dates)-1)}
