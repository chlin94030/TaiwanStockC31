"""Ten predeclared challengers; calculation is not evidence of usefulness."""
import numpy as np
import pandas as pd
from .factors import factor,ALL_H,_rev,_yoy

NAMES=('t_max20','t_lottery20','t_skew60','f_rev_surprise','f_rev_peer','c_trust60',
       'c_foreign_high','t_bb_squeeze','f_pe_own','f_dy_peer')

def peer(c,values):
    out=values.copy()*np.nan
    for _,group in c.P.info.groupby('sector'):
        if len(group)<5:continue
        a=values[group.index];valid=a.notna().sum(axis=1)>=5
        out.loc[:,group.index]=a.sub(a.median(axis=1),axis=0).where(valid,axis=0)
    return out

@factor('t_max20','T',1,ALL_H,'避開近20日單日極端大漲')
def max20(c):return -c.P['ret'].where(c.P['tradable']).rolling(20,min_periods=15).max()

@factor('t_lottery20','T',1,ALL_H,'低彩券型特徵（少漲停）')
def lottery(c):
    ret=c.P['ret'].where(c.P['tradable']);return -(ret>=.095).astype(float).where(ret.notna()).rolling(20,min_periods=15).mean()

@factor('t_skew60','T',1,ALL_H,'低正偏態（60日）')
def skew(c):return -c.P['ret'].where(c.P['tradable']).rolling(60,min_periods=40).skew()

@factor('f_rev_surprise','F',1,('mid','long'),'營收年增相對過去常態')
def surprise(c):
    def calc(r):
        y=_yoy(r);past=y.shift(1);sd=past.rolling(12,min_periods=8).std()
        return ((y-past.rolling(12,min_periods=8).mean())/sd.where(sd>1e-6)).clip(-5,5)
    return _rev(c,calc,'extra_rev_surprise')

@factor('f_rev_peer','F',1,('mid','long'),'營收成長領先同業')
def rev_peer(c):return peer(c,_rev(c,lambda r:_yoy(r,3),'extra_rev_peer'))

@factor('c_trust60','C',1,('mid','long'),'投信60日買超占股本')
def trust60(c):return c.rsum('trust',60)/c.shares

@factor('c_foreign_high','C',1,('mid','long'),'外資持股接近自身一年高點')
def foreign_high(c):
    if 'foreign_ratio' not in c.P.m:return pd.DataFrame(np.nan,index=c.P.dates,columns=c.P.tickers)
    x=c.P['foreign_ratio'];high=x.rolling(252,min_periods=120).max()
    return (x-high)/high.where(high>0)

@factor('t_bb_squeeze','T',0,ALL_H,'布林帶寬相對收斂')
def squeeze(c):
    width=4*c.adj.rolling(20,min_periods=20).std()/c.ma(20)
    return -width/width.rolling(60,min_periods=40).median().where(lambda x:x>0)

@factor('f_pe_own','F',1,('mid','long'),'本益比位於自身歷史低檔')
def pe_own(c):return -c.P['pe'].where(c.P['pe']>0).rolling(252,min_periods=126).rank(pct=True)

@factor('f_dy_peer','F',1,('mid','long'),'殖利率領先同業')
def dy_peer(c):return peer(c,c.P['dy'])
