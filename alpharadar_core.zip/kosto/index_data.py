"""Monthly official TAIEX OHLC and turnover. Never manufacture candles from closes."""
import pandas as pd
from .sources.official import find_col,roc_to_date,num,SourceError

def parse(ohlc,amount):
    def table(j):
        if str(j.get('stat','')).upper()!='OK':raise SourceError('加權指數報表未成功')
        return j['fields'],j['data']
    fields,data=table(ohlc);cols={k:find_col(fields,*v) for k,v in {'date':['日期'],'open':['開盤指數'],'high':['最高指數'],'low':['最低指數'],'close':['收盤指數']}.items()}
    if any(v is None for v in cols.values()):raise SourceError('加權指數OHLC欄位不符')
    rows=[{k:roc_to_date(row[i]) if k=='date' else num(row[i]) for k,i in cols.items()} for row in data]
    frame=pd.DataFrame(rows);fields,data=table(amount);date=find_col(fields,'日期');value=find_col(fields,'成交金額')
    if date is None or value is None:raise SourceError('大盤成交金額欄位不符')
    money=pd.DataFrame([{'date':roc_to_date(r[date]),'amount':num(r[value])} for r in data])
    frame=frame.merge(money,on='date',how='left');frame['ticker']='TAIEX';return frame.dropna(subset=['date','close'])

def update(store,http,start,end,log=print):
    start,end=pd.Timestamp(start),pd.Timestamp(end);months=pd.period_range(start,end,freq='M')
    done=store.done_set('index_month');rows=0
    for month in months[::-1]:
        if str(month) in done and month<months[-1]:continue
        http.check();params={'date':month.start_time.strftime('%Y%m%d'),'response':'json'}
        try:
            o=http.get('https://www.twse.com.tw/indicesReport/MI_5MINS_HIST',params)
            a=http.get('https://www.twse.com.tw/rwd/zh/afterTrading/FMTQIK',params)
            f=parse(o,a)
            if not f.empty and not (f.date.dt.to_period('M')==month).all():raise SourceError('來源回傳月份不符，不標記歷史完成')
            if f.empty:continue
            store.append('index',f);rows+=len(f)
            if month<months[-1]:store.mark_done('index_month',[str(month)]);store.save_state()
            log(f'加權指數 {month}：已存 {len(f)} 日')
        except SourceError as exc:log('加權指數暫未取得：'+str(exc));break
    return {'rows':rows}
