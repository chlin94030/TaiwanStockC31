"""Small, verified publication contract. The viewer never downloads a research database."""
from __future__ import annotations
import configparser,gzip,hashlib,io,json,os,re,threading,time
import math
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
import requests

LIVE_TAG='alpharadar-live'
DATA_TAG='alpharadar-data'
STATE_TAG='alpharadar-state'
MARKER='ALPHARADAR_PUBLICATION_V1\n'
MAX_JSON=32_000_000

def now():return datetime.now(ZoneInfo('Asia/Taipei')).isoformat(timespec='seconds')
def digest(data):return hashlib.sha256(data).hexdigest()
def atomic(path,content):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_suffix(f'.{os.getpid()}.{threading.get_ident()}.tmp');tmp.write_bytes(content);tmp.replace(path)

def encode(payload):
    validate(payload)
    return gzip.compress(json.dumps(payload,ensure_ascii=False,allow_nan=False,separators=(',',':')).encode(),mtime=0)

def decode(content):
    if len(content)>MAX_JSON:raise ValueError('發布檔過大')
    with gzip.GzipFile(fileobj=io.BytesIO(content)) as f:raw=f.read(MAX_JSON+1)
    if len(raw)>MAX_JSON:raise ValueError('發布內容過大')
    data=json.loads(raw);validate(data);return data

def validate(p):
    if p.get('schema')!=1 or not isinstance(p.get('models'),dict) or not isinstance(p.get('stocks'),dict):raise ValueError('發布格式不符')
    if p.get('state') not in ('initial_screen','research'):raise ValueError('發布階段不符')
    day=p.get('research_date','')
    if not re.fullmatch(r'\d{4}-\d{2}-\d{2}',day):raise ValueError('研究日期缺漏')
    datetime.fromisoformat(p['published_at'])
    if set(p['models'])!={'short','mid','long'}:raise ValueError('三個週期未完整發布')
    for h,m in p['models'].items():
        if m.get('asof')!=day:raise ValueError('模型日期混用')
        if not isinstance(m.get('picks'),list) or not m.get('id'):raise ValueError('模型名單或識別缺漏')
        if not isinstance(m.get('label'),str) or any(not isinstance(m.get(k),dict) for k in ('weights','metric','curve','recipe')):raise ValueError('模型成果欄位不足')
        if p['state']=='research' and not isinstance(m['recipe'].get('model',{}).get('k'),int):raise ValueError('模型配方缺漏')
        for pick in m['picks']:
            if not isinstance(pick.get('rank'),int) or not isinstance(pick.get('reasons'),list):raise ValueError('推薦解釋缺漏')
            if not isinstance(pick.get('coverage'),(float,int)) or not 0<=pick['coverage']<=1:raise ValueError('涵蓋率錯誤')
            if not isinstance(pick.get('score'),(float,int)) or not math.isfinite(pick['score']):raise ValueError('分數錯誤')
        if any(str(x['ticker']) not in p['stocks'] for x in m['picks']):raise ValueError('名單缺少個股資料')
        if p.get('synthetic') and m.get('certified'):raise ValueError('合成資料不能標示正式驗效')
    for s in p['stocks'].values():
        if any(k not in s for k in ('name','board','group','close','asof','plans','ranks')):raise ValueError('個股資料欄位缺漏')
    return p

def detect_repo(root,explicit=''):
    value=explicit or os.getenv('ALPHARADAR_REPO') or os.getenv('GITHUB_REPO') or os.getenv('GITHUB_REPOSITORY') or ''
    if not value:
        try:
            cfg=configparser.ConfigParser();cfg.read(Path(root)/'.git'/'config')
            remote=cfg.get('remote "origin"','url',fallback='');match=re.search(r'github\.com[:/]([^/]+/[^/]+?)(?:\.git)?$',remote)
            value=match.group(1) if match else ''
        except (OSError,configparser.Error):pass
    return value if re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+',value) else ''

class GitHub:
    def __init__(self,repo,token=None,session=None):
        self.repo=detect_repo('.',repo)
        if not self.repo:raise ValueError('需要有效儲存庫名稱')
        self.s=session or requests.Session();self.headers={'Accept':'application/vnd.github+json'}
        if token:self.headers['Authorization']='Bearer '+token
    def api(self,path,method='GET',**kw):
        r=self.s.request(method,'https://api.github.com/repos/'+self.repo+'/'+path,headers=self.headers,timeout=(4,15),**kw)
        if r.status_code==404 and method=='GET':return None
        r.raise_for_status();return r.json() if r.content else None
    def release(self,tag,create=False):
        r=self.api('releases/tags/'+tag)
        if r is None and create:
            try:r=self.api('releases','POST',json={'tag_name':tag,'name':tag,'make_latest':'false'})
            except requests.HTTPError as exc:
                if exc.response is None or exc.response.status_code!=422:raise
                r=self.api('releases/tags/'+tag)
                if r is None:raise
        if r and len(r.get('assets',[]))>=30:
            assets=[];page=1
            while True:
                batch=self.api(f'releases/{r["id"]}/assets?per_page=100&page={page}') or [];assets.extend(batch)
                if len(batch)<100:break
                page+=1
            r['assets']=assets
        return r
    def asset(self,asset):
        url=asset.get('url','')
        if not url.startswith('https://api.github.com/'):raise ValueError('資產位址無效')
        headers={**self.headers,'Accept':'application/octet-stream'}
        with self.s.get(url,headers=headers,timeout=(4,20),stream=True) as r:
            r.raise_for_status();parts=[];size=0
            for chunk in r.iter_content(65536):
                size+=len(chunk)
                if size>MAX_JSON:raise ValueError('下載資產過大')
                parts.append(chunk)
        return b''.join(parts)
    def upload(self,tag,path,replace=False):
        path=Path(path);rel=self.release(tag,True)
        # Checkpoints are immutable too. An interrupted upload must not delete
        # the only usable database or model state before its replacement exists.
        archive=replace and tag in (DATA_TAG,STATE_TAG) and path.name.endswith('.tar.gz')
        upload_name=path.name
        if archive:
            with path.open('rb') as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
            upload_name=path.name[:-7]+'-'+sha+'.tar.gz'
        existing=next((a for a in rel['assets'] if a['name']==upload_name),None)
        if archive and existing:return existing
        if existing and not replace:return existing
        if existing:self.api('releases/assets/'+str(existing['id']),'DELETE')
        upload=rel['upload_url'].split('{')[0]
        if not upload.startswith('https://uploads.github.com/'):raise ValueError('上傳位址無效')
        with path.open('rb') as f:
            r=self.s.post(upload,params={'name':upload_name},data=f,headers={**self.headers,'Content-Type':'application/octet-stream'},timeout=(5,600))
        r.raise_for_status();result=r.json()
        if archive:
            old=[a for a in rel['assets'] if re.fullmatch(re.escape(path.name[:-7])+r'-[a-f0-9]{64}\.tar\.gz',a['name'])]
            # Keep the new archive plus two preceding versions; legacy fixed-name
            # archives remain available as migration fallbacks.
            for a in sorted(old,key=lambda a:a.get('id',0),reverse=True)[2:]:
                try:self.api('releases/assets/'+str(a['id']),'DELETE')
                except requests.RequestException:pass
        return result
    @staticmethod
    def archive_asset(rel,name):
        pattern=re.escape(name[:-7])+r'-[a-f0-9]{64}\.tar\.gz' if name.endswith('.tar.gz') else None
        candidates=[a for a in rel.get('assets',[]) if a.get('state','uploaded')=='uploaded' and
                    (a['name']==name or pattern and re.fullmatch(pattern,a['name']))]
        return max(candidates,key=lambda a:(a.get('updated_at',''),a.get('id',0)),default=None)
    def download(self,tag,name,path,limit=2_000_000_000):
        rel=self.release(tag)
        if not rel:return False
        asset=self.archive_asset(rel,name)
        if asset is None:return False
        path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_suffix('.download')
        total=0;checksum=hashlib.sha256()
        try:
            with self.s.get(asset['url'],headers={**self.headers,'Accept':'application/octet-stream'},timeout=(5,120),stream=True) as r,tmp.open('wb') as f:
                r.raise_for_status()
                for chunk in r.iter_content(1024*1024):
                    total+=len(chunk)
                    if total>limit:raise ValueError('資料檢查點過大')
                    f.write(chunk);checksum.update(chunk)
            match=re.search(r'-([a-f0-9]{64})\.tar\.gz$',asset['name'])
            if match and checksum.hexdigest()!=match.group(1):raise ValueError('資料檢查點雜湊不符，保留原資料')
            tmp.replace(path);return True
        finally:
            if tmp.exists():tmp.unlink()
    def publish(self,path,metadata):
        raw=Path(path).read_bytes();payload=decode(raw);name='dashboard-'+digest(raw)+'.json.gz'
        target=Path(path).with_name(name);atomic(target,raw);self.upload(LIVE_TAG,target)
        rel=self.release(LIVE_TAG)
        # One PATCH is the publication boundary: a reader sees one complete descriptor.
        history=[]
        if str(rel.get('body','')).startswith(MARKER):
            try:
                old=json.loads(rel['body'][len(MARKER):]);history=[{k:v for k,v in old.items() if k!='history'}]+old.get('history',[])[:6]
            except ValueError:pass
        manifest={'schema':1,'asset':name,'sha256':digest(raw),'size':len(raw),'research_date':payload['research_date'],
                  'chart_assets':[d['asset'] for d in payload.get('chart_shards',{}).values()],'history':history,**metadata}
        response=self.api('releases/'+str(rel['id']),'PATCH',json={'body':MARKER+json.dumps(manifest,ensure_ascii=False)})
        manifest['announced_at']=response.get('updated_at',now())
        # Retain seven previous publications and their chart shards. Only this app's
        # hash-named generated assets are eligible for pruning.
        keep={manifest['asset'],*manifest['chart_assets']}
        for old in history:keep.update([old['asset'],*old.get('chart_assets',[])])
        for asset in rel.get('assets',[]):
            generated=re.fullmatch(r'(?:dashboard|charts-[0-9])-[a-f0-9]{64}\.json\.gz',asset['name'])
            if generated and asset['name'] not in keep:
                try:self.api('releases/assets/'+str(asset['id']),'DELETE')
                except requests.RequestException:pass
        return manifest
    def runs(self):
        result=self.api('actions/workflows/pipeline.yml/runs?per_page=3') or {}
        return [{k:x.get(k) for k in ('id','status','conclusion','html_url','updated_at','created_at')} for x in result.get('workflow_runs',[])]

class PublishedClient:
    def __init__(self,root,repo='',token=None,github=None):
        self.root=Path(root);self.repo=detect_repo(root,repo);self.github=github or (GitHub(self.repo,token) if self.repo else None);self.interval=60 if token else 300
        self.cache=self.root/'artifacts'/'published_dashboard.json.gz';self.payload=None
        self.status={'message':'等待 GitHub 已發布成果','runs':[]};self.running=False;self.last=-1e9;self.sha=''
        for path in (self.cache,Path(__file__).with_name('data')/'published_seed.json.gz'):
            try:self.payload=decode(path.read_bytes());break
            except (OSError,ValueError,EOFError):continue
        self.lock=threading.RLock()
    def refresh(self,force=False):
        with self.lock:
            if not self.github or self.running or (not force and time.monotonic()-self.last<self.interval):return
            self.running=True;self.last=time.monotonic()
        def worker():
            try:
                rel=self.github.release(LIVE_TAG)
                if not rel or not str(rel.get('body','')).startswith(MARKER):raise ValueError('首次研究尚未發布，保留啟動名單')
                m=json.loads(rel['body'][len(MARKER):]);sha=m.get('sha256','')
                if not re.fullmatch(r'[a-f0-9]{64}',sha) or m.get('asset')!='dashboard-'+sha+'.json.gz':raise ValueError('發布識別不符')
                if sha!=self.sha:
                    asset=next(a for a in rel['assets'] if a['name']==m['asset']);content=self.github.asset(asset)
                    if digest(content)!=sha:raise ValueError('發布檔雜湊不符，沿用前次成果')
                    payload=decode(content)
                    if payload['research_date']!=m.get('research_date'):raise ValueError('發布日期不符')
                    if self.payload and payload['research_date']<self.payload['research_date']:raise ValueError('來源日期倒退')
                    atomic(self.cache,content)
                    with self.lock:self.payload=payload;self.sha=sha
                self.status.update(message='已讀取完整發布成果',manifest=m)
            except Exception as e:self.status['message']=f'更新暫未完成，保留前次成果（{type(e).__name__}）'
            finally:
                try:self.status['runs']=self.github.runs()
                except Exception:self.status['runs_error']='GitHub 狀態暫不可查，未標示成功'
                try:
                    progress=self.github.release('alpharadar-status')
                    if progress:self.status['pipeline']=json.loads(progress.get('body') or '{}')
                except Exception:pass
                self.running=False
        threading.Thread(target=worker,daemon=True,name='published-reader').start()
    def stock_chart(self,ticker):
        p=self.payload or {}
        if ticker in p.get('charts',{}):return p['charts'][ticker]
        d=p.get('chart_shards',{}).get(str(ticker)[-1])
        if not d or not self.github:return None
        name=d['asset'];sha=d['sha256']
        if not re.fullmatch(r'[a-f0-9]{64}',sha) or name!=f'charts-{str(ticker)[-1]}-{sha}.json.gz':raise ValueError('圖表分片格式不符')
        cache=self.root/'artifacts'/'charts'/name
        content=cache.read_bytes() if cache.exists() else None
        if content is None:
            rel=self.github.release(LIVE_TAG);asset=next(x for x in rel['assets'] if x['name']==name);content=self.github.asset(asset)
            if digest(content)!=sha:raise ValueError('圖表資料驗證失敗')
            atomic(cache,content)
        if digest(content)!=sha:raise ValueError('圖表快取驗證失敗')
        with gzip.GzipFile(fileobj=io.BytesIO(content)) as f:raw=f.read(MAX_JSON+1)
        if len(raw)>MAX_JSON:raise ValueError('圖表內容過大')
        return json.loads(raw).get(ticker)
